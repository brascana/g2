
import dme.forecastiolib.*;

public class ForecastDownload {
	
	public ForecastDownload() {
		
		String [][][] coords; 
		
		ForecastIO fio = 
				new  ForecastIO("40","-74","6d1850be3f2cc59dffe3293c80e711ee");
		
		System.out.println(fio.getDaily());
				
	}
	public static void main (String[] args) {
		ForecastDownload fd = new ForecastDownload();
	}
}
