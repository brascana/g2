package com.damresults.ui;

import java.awt.Color;

public class ColorScale {
	
	public Color getColor(double num) {

		int red = 139;
		int green = 244;
		int blue = 255;
				
		if(num < 0) {
			
			red =83;
			green = 88;
			blue = 229;
			
		} else if (num >=0 && num <=100) {
			red = 83 + (int)(1.46*num);
			green = 219;
			blue = 180;
			
		} else {
			red = 229;
			green = 265 -(int) (0.365*num);
			blue = 150;	
						
		}		
		return new Color(red,green,blue);
	}

}
