package com.damresults.ui;

import java.awt.Color;
import java.awt.Font;
import java.text.DecimalFormat;

import javax.swing.SwingConstants;


public class GenLbmpTotalCellRenderer extends GenLbmpCellRenderer {

	private static final long serialVersionUID = 1L;

	public GenLbmpTotalCellRenderer() {
		setHorizontalAlignment(SwingConstants.RIGHT);
		setBackground(Color.WHITE);

}

	@Override
	public void setValue(Object aValue) {
		Object result = aValue;
		
		if ((aValue != null) ) {

			setFont(new Font("SansSerif", Font.BOLD, 12));
			double d = Double.parseDouble((String) aValue);
			
			setBackground(new ColorScale().getColor(d));
			
			DecimalFormat df = new DecimalFormat("#.00");
			result = df.format(d);
		}
		super.setValue(result);
	}
}