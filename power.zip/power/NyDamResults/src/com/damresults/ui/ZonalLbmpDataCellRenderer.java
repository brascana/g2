package com.damresults.ui;

import java.awt.Color;
import java.text.DecimalFormat;

import javax.swing.SwingConstants;

public class ZonalLbmpDataCellRenderer extends ZonalLbmpCellRenderer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8240382174165446943L;


	public ZonalLbmpDataCellRenderer() {

		setHorizontalAlignment(SwingConstants.RIGHT);
		setBackground(Color.WHITE);

	}

	@Override
	public void setValue(Object aValue) {
		Object result = aValue;

		if ((aValue != null)) {

			double d = Double.parseDouble((String) aValue);

			DecimalFormat df = new DecimalFormat("#.00");
			result = df.format(d);

		}
		super.setValue(result);
	}

}
