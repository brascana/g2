package com.damresults.ui.dialog;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import com.damresults.ui.tablerenderer.CustomCellRenderer;
import com.damresults.ui.tablerenderer.DailyEnergyDataCellRenderer;

public class AtcTtcPanel extends javax.swing.JPanel {
	
	private static final long serialVersionUID = 3981505501582963902L;
	
	private javax.swing.JTable atcTable;
	private javax.swing.JScrollPane atcScrollPane;
	
	private DefaultTableModel tableModel;
	private ArrayList<String[]> tableData;
	
	public AtcTtcPanel() {
		initComponents();
	}
	
	private void initComponents() {
		

		atcScrollPane = new javax.swing.JScrollPane();
		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		//atcScrollPane.setViewportView(atcTable);
		
		add(atcScrollPane);
	}
	public void updateTableData(DefaultTableModel tm, ArrayList<String[]> t) {

		tableModel = tm;
		tableData = t;

		for (String[] s : tableData) {
			tableModel.addRow(s);
		}

	}
	public void refreshAtcTable() {
		
		atcTable = new JTable(tableModel);
		
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(
				tableModel);
		
		atcTable.setRowSorter(sorter);
		atcTable.getRowSorter().toggleSortOrder(0);
		
		atcTable.setShowGrid(false);
		atcTable.getColumnModel().getColumn(0).setPreferredWidth(150);
	
		atcTable.getColumnModel().getColumn(0)
		.setCellRenderer(new CustomCellRenderer());
		
		for (int i = 1; i < atcTable.getColumnCount(); i++) {
			atcTable.getColumnModel().getColumn(i).setPreferredWidth(43);
			atcTable.getColumnModel().getColumn(i)
					.setCellRenderer(new DailyEnergyDataCellRenderer());
		}
		
		atcScrollPane.setViewportView(atcTable);
		atcScrollPane.getViewport().setBackground(Color.WHITE);
		
	}

		
	
}
