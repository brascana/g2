package com.damresults.ui.dialog;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.damresults.ui.tablerenderer.CustomCellRenderer;
import com.damresults.ui.tablerenderer.LConstraintDataCellRenderer;

public class LimitingConstraintPanel extends JPanel {
	
	private static final long serialVersionUID = 462897020000456376L;
	
	private JTable lcTable;
	private JScrollPane lcScrollPane;
	
	private DefaultTableModel tableModel;
	private ArrayList<String[]> tableData;
	
	public LimitingConstraintPanel() {
		initComponents();
	}
	
	private void initComponents() {
		
		lcScrollPane = new JScrollPane();
		
		lcScrollPane.setViewportView(lcTable);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		add(lcScrollPane);
		
	}
	
	public void updateTable(DefaultTableModel tm, ArrayList<String[]> t) {
		tableModel = tm;
		tableData = t;
		
		for (String[] s : tableData) {
			tableModel.addRow(s);
		}
	}
	
	public void refreshLcTable() {
		
		lcTable = new JTable(tableModel);
		
		lcTable.setShowGrid(false);
		lcTable.getColumnModel().getColumn(0).setPreferredWidth(150);
		lcTable.getColumnModel().getColumn(1).setPreferredWidth(150);
		lcTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		lcTable.getColumnModel().getColumn(0)
		.setCellRenderer(new CustomCellRenderer());
		
		lcTable.getColumnModel().getColumn(1)
		.setCellRenderer(new CustomCellRenderer());

		for (int i = 2; i < lcTable.getColumnCount(); i++) {
			lcTable.getColumnModel().getColumn(i).setPreferredWidth(45);
			lcTable.getColumnModel().getColumn(i).setCellRenderer(new LConstraintDataCellRenderer());
		}
		
		lcScrollPane.setViewportView(lcTable);
		lcScrollPane.getViewport().setBackground(Color.WHITE);
	}
	

}
