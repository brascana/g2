package com.damresults.ui.dialog;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.DefaultRowSorter;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import com.damresults.ui.tablerenderer.CustomCellRenderer;
import com.damresults.ui.tablerenderer.DailyEnergyDataCellRenderer;

public class DailyEnergyDniPanel extends javax.swing.JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4574553267669664318L;

	private javax.swing.JLabel dniLabel;
	private javax.swing.JLabel importLabel;
	private javax.swing.JLabel exportLabel;
	private javax.swing.JScrollPane dniScrollPane;
	private javax.swing.JScrollPane exportScrollPane;
	private javax.swing.JScrollPane importScrollPane;
	private javax.swing.JTable dniTable;
	private javax.swing.JTable exportTable;
	private javax.swing.JTable importTable;

	private DefaultTableModel tableModel;
	private ArrayList<String[]> tableData;

	public DailyEnergyDniPanel() {
		initComponents();
	}

	private void initComponents() {

		dniScrollPane = new javax.swing.JScrollPane();
		dniTable = new javax.swing.JTable();
		dniLabel = new javax.swing.JLabel();
		importLabel = new javax.swing.JLabel();
		exportScrollPane = new javax.swing.JScrollPane();
		exportLabel = new javax.swing.JLabel();
		importScrollPane = new javax.swing.JScrollPane();

		dniLabel.setText("DNI");
		importLabel.setText("Imports");
		exportLabel.setText("Exports");

		exportScrollPane.setViewportView(exportTable);

		importScrollPane.setViewportView(importTable);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		add(dniLabel);
		add(dniScrollPane);
		add(importLabel);
		add(importScrollPane);
		add(exportLabel);
		add(exportScrollPane);
	}
	
	public void updateTableData(DefaultTableModel tm, ArrayList<String[]> t) {

		tableModel = tm;
		tableData = t;

		for (String[] s : tableData) {
			tableModel.addRow(s);
		}

	}

	@SuppressWarnings("unchecked")
	public void refreshDniTable() {

		dniTable = new JTable(tableModel);

		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(
				tableModel);

		RowFilter<Object, Object> filter = new RowFilter<Object, Object>() {
			public boolean include(@SuppressWarnings("rawtypes") Entry entry) {
				String name = (String) entry.getValue(0);
				return (name.contains("Proxy DNI"));
			}
		};

		((DefaultRowSorter<TableModel, Integer>) sorter).setRowFilter(filter);

		dniTable.setRowSorter(sorter);
		dniTable.getRowSorter().toggleSortOrder(0);

		dniTable.setShowGrid(false);
		dniTable.getColumnModel().getColumn(0).setPreferredWidth(150);

		dniTable.getColumnModel().getColumn(0)
				.setCellRenderer(new CustomCellRenderer());

		dniTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		for (int i = 1; i < dniTable.getColumnCount(); i++) {
			dniTable.getColumnModel().getColumn(i).setPreferredWidth(45);
			dniTable.getColumnModel().getColumn(i)
					.setCellRenderer(new DailyEnergyDataCellRenderer());
		}

		dniScrollPane.setViewportView(dniTable);
		dniScrollPane.getViewport().setBackground(Color.WHITE);

	}

	@SuppressWarnings("unchecked")
	public void refreshImportTable() {

		importTable = new JTable(tableModel);

		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(
				tableModel);

		RowFilter<Object, Object> filter = new RowFilter<Object, Object>() {
			public boolean include(@SuppressWarnings("rawtypes") Entry entry) {
				String name = (String) entry.getValue(0);
				return (name.contains("Proxy Import"));
			}
		};

		((DefaultRowSorter<TableModel, Integer>) sorter).setRowFilter(filter);

		importTable.setRowSorter(sorter);
		importTable.getRowSorter().toggleSortOrder(0);

		importTable.setShowGrid(false);
		importTable.getColumnModel().getColumn(0).setPreferredWidth(150);

		importTable.getColumnModel().getColumn(0)
				.setCellRenderer(new CustomCellRenderer());

		importTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		for (int i = 1; i < importTable.getColumnCount(); i++) {
			importTable.getColumnModel().getColumn(i).setPreferredWidth(45);
			importTable.getColumnModel().getColumn(i)
					.setCellRenderer(new DailyEnergyDataCellRenderer());
		}

		importScrollPane.setViewportView(importTable);
		importScrollPane.getViewport().setBackground(Color.WHITE);

	}

	@SuppressWarnings("unchecked")
	public void refreshExportTable() {

		exportTable = new JTable(tableModel);

		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(
				tableModel);

		RowFilter<Object, Object> filter = new RowFilter<Object, Object>() {
			public boolean include(@SuppressWarnings("rawtypes") Entry entry) {
				String name = (String) entry.getValue(0);
				return (name.contains("Proxy Export"));
			}
		};

		((DefaultRowSorter<TableModel, Integer>) sorter).setRowFilter(filter);

		exportTable.setRowSorter(sorter);
		exportTable.getRowSorter().toggleSortOrder(0);

		exportTable.setShowGrid(false);
		exportTable.getColumnModel().getColumn(0).setPreferredWidth(150);

		exportTable.getColumnModel().getColumn(0)
				.setCellRenderer(new CustomCellRenderer());

		exportTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		for (int i = 1; i < exportTable.getColumnCount(); i++) {
			exportTable.getColumnModel().getColumn(i).setPreferredWidth(45);
			exportTable.getColumnModel().getColumn(i)
					.setCellRenderer(new DailyEnergyDataCellRenderer());
		}

		exportScrollPane.setViewportView(exportTable);
		exportScrollPane.getViewport().setBackground(Color.WHITE);

	}

}
