package com.damresults.ui.dialog;

import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import com.damresults.model.GenLbmp;
import com.damresults.ui.GenLbmpCellRenderer;
import com.damresults.ui.GenLbmpDataCellRenderer;
import com.damresults.ui.GenLbmpTotalCellRenderer;

public class GenLbmpPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6808969458102496508L;
	
	private JTable genTable;
	private JScrollPane genScrollPane;
	private JPanel topPanel;
	
	private DefaultTableModel tableModel;
	private ArrayList<String[]> tableData;
	
	private static JButton genLmpBtn;
	private static JButton genLossBtn;
	private static JButton genCongBtn;
	
	public GenLbmpPanel() {
		initComponents();
	}
	
	public void initComponents() {
		genScrollPane = new JScrollPane();
		
			
		topPanel = new JPanel();
		topPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		
		javax.swing.GroupLayout genTopTabPanelLayout = 
				new javax.swing.GroupLayout(topPanel);
		
		javax.swing.GroupLayout jPanel1Layout = 
				new javax.swing.GroupLayout(this);
		
		topPanel.setLayout(genTopTabPanelLayout);
		
		genLmpBtn = new javax.swing.JButton();
		genLossBtn = new javax.swing.JButton();
		genCongBtn = new javax.swing.JButton();
		
		genLmpBtn.setText("Lmp");
		genLossBtn.setText("Loss");
		genCongBtn.setText("Cong");
		

		genTopTabPanelLayout.setHorizontalGroup(genTopTabPanelLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(genTopTabPanelLayout
				.createSequentialGroup()
				.addContainerGap()
				.addComponent(genLmpBtn)
				.addComponent(genLossBtn)
				.addComponent(genCongBtn)
				.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE,Short.MAX_VALUE)));
		
		genTopTabPanelLayout
				.setVerticalGroup(genTopTabPanelLayout
				.createParallelGroup(
						javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,genTopTabPanelLayout
				.createSequentialGroup()
				.addGroup(genTopTabPanelLayout
				.createParallelGroup(
						javax.swing.GroupLayout.Alignment.BASELINE)
				.addComponent(genLmpBtn)
				.addComponent(genLossBtn)
				.addComponent(genCongBtn))));
		
		this.setLayout(jPanel1Layout);
		
		jPanel1Layout.setHorizontalGroup(jPanel1Layout
				.createParallelGroup(
						javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(topPanel,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						Short.MAX_VALUE)
				.addComponent(genScrollPane,
						javax.swing.GroupLayout.DEFAULT_SIZE, 878,
						Short.MAX_VALUE));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
				.createParallelGroup(
						javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout
				.createSequentialGroup()
				.addComponent(topPanel,
						javax.swing.GroupLayout.PREFERRED_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(
						javax.swing.LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(
						genScrollPane,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						546, Short.MAX_VALUE)));
	}
	
	public void updateTable(GenLbmp gLbmp) {
		
		tableModel = new DefaultTableModel(gLbmp
				.getCrossTab().getColHeaders(), 0);
		
		tableData = gLbmp.getCrossTab().getTableData();
		
		for (String[] s : tableData) {
			tableModel.addRow(s);
		}
	}
	
	public void refreshGenTable() {
		
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(
				tableModel);

		genTable = new JTable(tableModel);
		
		
		genTable.setRowSorter(sorter);
		genTable.getRowSorter().toggleSortOrder(0);
		

		genTable.setShowGrid(false);
		genTable.getColumnModel().getColumn(0).setPreferredWidth(150);
		genTable.getColumnModel().getColumn(1).setPreferredWidth(50);
		genTable.getColumnModel().getColumn(2).setPreferredWidth(50);
		genTable.getColumnModel().getColumn(3).setPreferredWidth(50);
		genTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		genTable.setIntercellSpacing(new Dimension(0,0));
		
		genTable.getColumnModel().getColumn(0)
		.setCellRenderer(new GenLbmpCellRenderer());

		for (int i = 1; i < genTable.getColumnCount(); i++) {

			if (i >= 4) {
				genTable.getColumnModel().getColumn(i)
					.setCellRenderer(new GenLbmpDataCellRenderer());
				
				genTable.getColumnModel().getColumn(i).setPreferredWidth(48);
			}else {
				genTable.getColumnModel().getColumn(i)
					.setCellRenderer(new GenLbmpTotalCellRenderer());
				
			}
			

		}
		genScrollPane.setViewportView(genTable);
		genScrollPane.getViewport().setBackground(Color.WHITE);
		
	}
	

}
