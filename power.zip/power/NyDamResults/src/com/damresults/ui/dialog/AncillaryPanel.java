	package com.damresults.ui.dialog;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.damresults.ui.tablerenderer.AncillaryDataCellRenderer;
import com.damresults.ui.tablerenderer.CustomCellRenderer;

public class AncillaryPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8470855255297847398L;
	
	private JTable ancTable;
	private JScrollPane ancScrollPane;
	
	private DefaultTableModel tableModel;
	private ArrayList<String[]> tableData;
	
	public AncillaryPanel() {
		initComponents();
	}
	
	private void initComponents() {
		
		ancScrollPane = new JScrollPane();
		ancScrollPane.setViewportView(ancTable);
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		add(ancScrollPane);
		
	}
	
	public void updateTable(DefaultTableModel tm, ArrayList<String[]> t) {
		tableModel = tm;
		tableData = t;
		
		for (String[] s : tableData) {
			tableModel.addRow(s);
		}
	}
	
	public void refreshAncTable(){
		
		ancTable = new JTable(tableModel);
		
		ancTable.setShowGrid(false);
		ancTable.getColumnModel().getColumn(0).setPreferredWidth(150);
		ancTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		ancTable.getColumnModel().getColumn(0)
		.setCellRenderer(new CustomCellRenderer());

		for (int i = 1; i < ancTable.getColumnCount(); i++) {
			ancTable.getColumnModel().getColumn(i).setPreferredWidth(45);
			ancTable.getColumnModel().getColumn(i).setCellRenderer(new AncillaryDataCellRenderer());
		}
		
		ancScrollPane.setViewportView(ancTable);
		ancScrollPane.getViewport().setBackground(Color.WHITE);
		
	}

}
