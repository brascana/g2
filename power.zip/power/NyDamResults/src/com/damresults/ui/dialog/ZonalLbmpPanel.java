package com.damresults.ui.dialog;

import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

import com.damresults.ui.GenLbmpDataCellRenderer;
import com.damresults.ui.tablerenderer.AncillaryDataCellRenderer;
import com.damresults.ui.tablerenderer.CustomCellRenderer;

public class ZonalLbmpPanel extends JPanel {


	/**
	 * 
	 */
	private static final long serialVersionUID = -7291980317602959623L;
	
	private JTable zonalTable;
	private JScrollPane zonalScrollPane;
	
	private TableModel tableModel;
	
	public ZonalLbmpPanel() {
		initComponents();
	}
	
	private void initComponents() {
		
		zonalScrollPane = new JScrollPane();
		
		zonalScrollPane.setViewportView(zonalTable);
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		add(zonalScrollPane);
		
	}
	
	public void updateTable(TableModel tm) {
		tableModel = tm;

	}
	
	public void refreshZonalTable() {
		
		zonalTable = new JTable(tableModel);
		
		zonalTable.setShowGrid(false);
		zonalTable.getColumnModel().getColumn(0).setPreferredWidth(60);
		zonalTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		
		zonalTable.getColumnModel().getColumn(0)
			.setCellRenderer(new CustomCellRenderer());
		
		for (int i = 1; i < zonalTable.getColumnCount(); i++) {
			zonalTable.getColumnModel().getColumn(i).setPreferredWidth(52);
			
			zonalTable.getColumnModel().getColumn(i).setCellRenderer(new AncillaryDataCellRenderer());
		}
		
		zonalScrollPane.setViewportView(zonalTable);
		zonalScrollPane.getViewport().setBackground(Color.WHITE);
	}

}
