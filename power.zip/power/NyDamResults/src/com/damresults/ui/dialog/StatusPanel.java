package com.damresults.ui.dialog;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.BoxLayout;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.damresults.ping.QueryMetaData;

public class StatusPanel extends javax.swing.JPanel {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5325930233344741409L;
	private DefaultTableModel tableModel;
	private JScrollPane statusScrollPane;
	
	private javax.swing.JTable statusTable;
	
	private String[] columnNames = {"Description",
									"Status",
									"Start time",
									"Frequency (milliseconds)",
									"Last Update"};
	
	
	
	public StatusPanel() {
		
		
		initComponents();
	}
	
	private void initComponents() {
		
		statusScrollPane = new JScrollPane();
		
		
		tableModel = new DefaultTableModel(columnNames, 0);
		
		statusTable = new JTable(tableModel);
		statusScrollPane.setViewportView(statusTable);
		
		
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		add(statusScrollPane);
		
		
		
	}
	public synchronized void updateStatusTable(Hashtable<String, QueryMetaData> metaTable) {
		
		tableModel = new DefaultTableModel(columnNames, 0);
		
		
		
		Map<String, QueryMetaData> map = metaTable;

		Iterator<Entry<String, QueryMetaData>> it = map.entrySet()
				.iterator();

		while (it.hasNext()) {
			Entry<String, QueryMetaData> entry = it.next();

				QueryMetaData md = entry.getValue();
				
				String[] rowData = new String[5];
				rowData[0] = md.getName();
				rowData[1] = md.getStatus();
				rowData[2] = md.getStart();
				rowData[3] = ""+md.getFrequency();
				rowData[4] = md.getLastUpdate();
				
				tableModel.addRow(rowData);

		}
		statusTable = new JTable(tableModel);
		statusScrollPane.setViewportView(statusTable);
	}
	
	
		
}
