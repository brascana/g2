package com.damresults.ui.tablerenderer;

import java.awt.Color;
import java.text.DecimalFormat;

import javax.swing.SwingConstants;

public class AncillaryDataCellRenderer extends CustomCellRenderer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8240382174165446943L;


	public AncillaryDataCellRenderer() {

		setHorizontalAlignment(SwingConstants.RIGHT);
		//setBackground(Color.WHITE);

	}

	@Override
	public void setValue(Object aValue) {
		Object result = aValue;

		if ((aValue != null)) {

			double d = Double.parseDouble((String) aValue);
			
			if (d < 0){
				setForeground(Color.RED);
				d= d *-1;
			} else {
				setForeground(Color.BLACK);
			}

			DecimalFormat df = new DecimalFormat("0.00");
			result = df.format(d);

		}
		super.setValue(result);
	}

}