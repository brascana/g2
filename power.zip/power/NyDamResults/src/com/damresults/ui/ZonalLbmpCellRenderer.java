package com.damresults.ui;

import java.awt.Color;

import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;


public class ZonalLbmpCellRenderer extends DefaultTableCellRenderer {

	private static final long serialVersionUID = 1L;

	public ZonalLbmpCellRenderer() {

		setHorizontalAlignment(SwingConstants.LEFT);
		setBackground(Color.WHITE);

	}

	@Override
	public void setValue(Object aValue) {
		Object result = aValue;

		super.setValue(result);
	}
}