package com.damresults.model;

import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.powerlib.powergrid.NyisoAtcTtc;
import com.powerlib.powergrid.NyisoDailyEnergy;
import com.powerlib.query.csv.NyisoAtcQuery;
import com.powerlib.query.csv.NyisoDailyEnergyQuery;


public class AtcTtc {
	
	private HourlyCrossTab crossTab;
	private String baseUrl = "http://mis.nyiso.com/public/csv/atc_ttc/";
	
	//http://mis.nyiso.com/public/csv/atc_ttc/20150219atc_ttc.csv
	
	public AtcTtc(){
		crossTab = new HourlyCrossTab();
	}
	
	public boolean download(String dy) {
		
		try {
			
			NyisoAtcQuery nyttc =
					new NyisoAtcQuery(baseUrl+dy+"atc_ttc.csv");
			
			if (nyttc.query()) {
				
				crossTab.addHeader("Interface");
				
				LocalDate date = LocalDate.parse(dy,
						DateTimeFormat.forPattern("yyyyMMdd"));
				
				DateTime start = date.toDateTimeAtStartOfDay();
				DateTime end = start.plusDays(1);
				
				while (start.isBefore(end)) {
					
					int hourB = start.getHourOfDay();
					int hourE = hourB + 1;

					crossTab.addHeader(""+hourE);
					start = start.plusHours(1);
				}
							
				addData(nyttc.geAtcMap(),dy);
				
			}
			else {
				return false;
				//System.out.println("TEST");
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	public HourlyCrossTab getCrossTab(){
		return crossTab;
	}
	private void addData(HashMap<String, NyisoAtcTtc> map, String dy) {
		
		LocalDate date = LocalDate.parse(dy,
				DateTimeFormat.forPattern("yyyyMMdd"));
		
		DateTime start = date.toDateTimeAtStartOfDay();
		DateTime end = start.plusDays(1);
		
		for(String key: map.keySet()) {
			
			String[] rowData = 
					new String[crossTab.getColHeaders().length];
			
			NyisoAtcTtc nyat = map.get(key);
			
			rowData[0] =  nyat.getName();

			start= date.toDateTimeAtStartOfDay();
			end = start.plusDays(1);
			
			int r = 1;
			
			
			while (start.isBefore(end)) {

				if(nyat.containsHour(start)){
					rowData[r]= nyat.getHourlyValue(start)+"";
				}
				else {
					rowData[r]= "";
				}
							
				start = start.plusHours(1);
				r++;
			}
			
			crossTab.addDataRow(rowData);
			
		}
		
	}

}