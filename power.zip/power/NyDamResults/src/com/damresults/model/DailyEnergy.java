package com.damresults.model;

import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.powerlib.powergrid.NyisoDailyEnergy;
import com.powerlib.query.csv.NyisoDailyEnergyQuery;


public class DailyEnergy {
	
	private HourlyCrossTab crossTab;
	private String baseUrl = "http://mis.nyiso.com/public/csv/damenergy/";
	
	public DailyEnergy(){
		crossTab = new HourlyCrossTab();
	}
	
	public boolean download(String dy) {
		
		try {
			
			NyisoDailyEnergyQuery nyeng =
					new NyisoDailyEnergyQuery(baseUrl+dy+"DAM_energy_rep.csv");
			
			if (nyeng.query()) {
				
				crossTab.addHeader("Description");
				
				LocalDate date = LocalDate.parse(dy,
						DateTimeFormat.forPattern("yyyyMMdd"));
				
				DateTime start = date.toDateTimeAtStartOfDay();
				DateTime end = start.plusDays(1);
				
				while (start.isBefore(end)) {
					
					int hourB = start.getHourOfDay();
					int hourE = hourB + 1;

					crossTab.addHeader(""+hourE);
					start = start.plusHours(1);
				}
							
				addData(nyeng.getHourlyMap(),dy);
				
			}
			else {
				return false;
				//System.out.println("TEST");
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	public HourlyCrossTab getCrossTab(){
		return crossTab;
	}
	private void addData(HashMap<String, NyisoDailyEnergy> map, String dy) {
		
		LocalDate date = LocalDate.parse(dy,
				DateTimeFormat.forPattern("yyyyMMdd"));
		
		DateTime start = date.toDateTimeAtStartOfDay();
		DateTime end = start.plusDays(1);
		
		for(String key: map.keySet()) {
			
			String[] rowData = 
					new String[crossTab.getColHeaders().length];
			
			NyisoDailyEnergy nyde = map.get(key);
			
			rowData[0] =  nyde.getDescription();

			start= date.toDateTimeAtStartOfDay();
			end = start.plusDays(1);
			
			int r = 1;
			
			while (start.isBefore(end)) {

				if(nyde.containsHour(start)){
					rowData[r]= nyde.getHourlyValue(start)+"";
				}
				else {
					rowData[r]= "";
				}
							
				start = start.plusHours(1);
				r++;
			}
			
			crossTab.addDataRow(rowData);
			
		}
		
	}

}