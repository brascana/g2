package com.damresults.model;

import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.powerlib.powergrid.NyisoHourlyConstraint;
import com.powerlib.query.csv.NyisoDamConstraintQuery;

public class LimitingConstraint {
	
	private HourlyCrossTab crossTab;
	private String baseUrl = "http://mis.nyiso.com/public/csv/DAMLimitingConstraints/";
	
	public LimitingConstraint(){
		crossTab = new HourlyCrossTab();
	}
	
	public boolean download(String dy) {
		
		try {
			
			NyisoDamConstraintQuery nydam =
					new NyisoDamConstraintQuery(baseUrl+dy+"DAMLimitingConstraints.csv");

			
			if (nydam.query()) {
				
				crossTab.addHeader("Facility");
				crossTab.addHeader("Contingency");
				
				LocalDate date = LocalDate.parse(dy,
						DateTimeFormat.forPattern("yyyyMMdd"));
				
				DateTime start = date.toDateTimeAtStartOfDay();
				DateTime end = start.plusDays(1);
				
				while (start.isBefore(end)) {
					
					int hourB = start.getHourOfDay();
					int hourE = hourB + 1;

					crossTab.addHeader(""+hourE);
					start = start.plusHours(1);
				}

				
				HashMap<String, NyisoHourlyConstraint> hm = nydam.getConstraintMap();

				
				for(String key: hm.keySet()) {
					
					String[] rowData = 
							new String[crossTab.getColHeaders().length];
					
					NyisoHourlyConstraint nyps2 = hm.get(key);
					
					rowData[0] =  nyps2.getLimitingFacility();
					rowData[1] =  nyps2.getContingency();

					
					start= date.toDateTimeAtStartOfDay();
					end = start.plusDays(1);
					
					int r = 2;
					
					while (start.isBefore(end)) {
						
						if(nyps2.containsHour(start)){
							rowData[r]= nyps2.getHourlyCost(start)+"";
						}
						else {
							rowData[r]= "";
						}
									
					
						start = start.plusHours(1);
						r++;
					}
					
					crossTab.addDataRow(rowData);
					
				}
			}
			else {
				return false;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	public HourlyCrossTab getCrossTab(){
		return crossTab;
	}

}