package com.damresults.model;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Vector;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.csvreader.CsvReader;
import com.damresults.settings.DamLbmpSettings;
import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.query.csv.NyisoDamLmpQuery;
import com.powerlib.time.NyisoCalendar;

public class ZonalLbmp {

	private Vector<DamLbmpSettings> settings;
	private String settingsFileName = "dam_zonal_settings.csv";
	private String baseUrl = "http://mis.nyiso.com/public/csv/damlbmp/";
	private String lbmpColumns[];
	private String tableArray[][];

	/**
	 * 
	 * @return
	 */
	public boolean getSettings() {

		settings = new Vector<DamLbmpSettings>();

		try {
			
			BufferedReader bReader = new BufferedReader(new InputStreamReader(
                    this.getClass().getResourceAsStream(settingsFileName)));
			
			CsvReader damLbmpSettings = new CsvReader(bReader);
			damLbmpSettings.readHeaders();

			while (damLbmpSettings.readRecord()) {
				
				DamLbmpSettings dms = new DamLbmpSettings();
				dms.setType(damLbmpSettings.get("Type"));
				dms.setHeader(damLbmpSettings.get("Header"));
				dms.setSourcePtid(damLbmpSettings.get("Source PTID"));
				dms.setSource(damLbmpSettings.get("Source"));
				dms.setSinkPtid(damLbmpSettings.get("Sink PTID"));
				dms.setSource(damLbmpSettings.get("Sink"));

				settings.add(dms);
			}

			damLbmpSettings.close();

			lbmpColumns = new String[settings.size() + 1];
			lbmpColumns[0] = "";

			for (int i = 1; i <= settings.size(); i++) {
				lbmpColumns[i] = settings.get(i - 1).getHeader();
			}

		} catch (Exception e) {
			
			System.out.println("error downloading file");
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */

	public String[] getColumns() {
		return lbmpColumns;
	}

	/**
	 * 
	 * @return
	 */

	public boolean download(String dy) {

		LocalDate date = LocalDate.parse(dy,
				DateTimeFormat.forPattern("yyyyMMdd"));

		NyisoCalendar nycal = new NyisoCalendar();

		if (nycal.hasExtraHour(date)) {
			tableArray = new String[28][lbmpColumns.length];

		} else {
			tableArray = new String[27][lbmpColumns.length];
		}

		Arrays.fill(tableArray[0], " ");
		Arrays.fill(tableArray[1], " ");

		DateTime start = date.toDateTimeAtStartOfDay();
		DateTime end = start.plusDays(1);

		tableArray[0][0] = "PEAK";
		tableArray[1][0] = "OFF";
		tableArray[2][0] = "ATC";
		
		int r = 3;

		while (start.isBefore(end)) {

			int hourB = start.getHourOfDay();
			int hourE = hourB + 1;

			tableArray[r][0] = ""+hourE;

			start = start.plusHours(1);
			r++;
		}

		DecimalFormat df = new DecimalFormat("0.00");

		try {
		NyisoDamLmpQuery nydam = 
				new NyisoDamLmpQuery(baseUrl+dy+"damlbmp_zone.csv");
		

		if (nydam.query()) {

			HashMap<String, NyisoHourlyPriceSet> hm = nydam.getLbmpMap();

			int tblCol = 1;
			for (DamLbmpSettings d : settings) {

				NyisoHourlyPriceSet nyps2 = hm.get(d.getSourcePtid());

				int tblRow = 3;

				start = date.toDateTimeAtStartOfDay();
				end = start.plusDays(1);

				while (start.isBefore(end)) {

					if (nyps2.containsHour(start)) {
						try {
							if (d.getType().equals("Spread")) {
								NyisoHourlyPriceSet nyps3 = hm.get(d
										.getSinkPtid());
								
								double sreadVal = Math.round((nyps3
										.getHourlyPrice(start) - nyps2
										.getHourlyPrice(start)) * 100.0) / 100.0;

								tableArray[tblRow][tblCol] = 
										df.format(sreadVal);

							} else {
								
								tableArray[tblRow][tblCol] = 
										df.format(nyps2.getHourlyPrice(start));

							}
						} catch (Exception e) {
							System.out.println(tblRow + ", " + tblCol + ", "
									+ e);
							return false;
						}
					}
					start = start.plusHours(1);

					tblRow++;
				}

				double peakVal;
				double offPeakVal;
				double atcVal;

				if (d.getType().equals("Spread")) {

					NyisoHourlyPriceSet nyps3 = hm.get(d.getSinkPtid());

					peakVal = Math.round((nyps3.get7x16Price() - nyps2
							.get7x16Price()) * 100.0) / 100.0;

					offPeakVal = Math.round((nyps3.get7x8Price() - nyps2
							.get7x8Price()) * 100.0) / 100.0;

					atcVal = Math.round((nyps3.get7x24Price() - nyps2
							.get7x24Price()) * 100.0) / 100.0;

				} else {
					peakVal = nyps2.get7x16Price();
					offPeakVal = nyps2.get7x8Price();
					atcVal = nyps2.get7x24Price();
				}

				
				tableArray[0][tblCol] = df.format(peakVal);
				tableArray[1][tblCol] = df.format(offPeakVal);
				tableArray[2][tblCol] = df.format(atcVal);

				tblCol++;

			}

		} else {
			return false;
		}
		}catch(Exception e){return false;}
		
		return true;
	}
	public String[][] getTableArray() {
		return tableArray;
	}

}
