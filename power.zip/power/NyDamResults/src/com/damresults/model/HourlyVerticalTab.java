package com.damresults.model;

public class HourlyVerticalTab {

}
