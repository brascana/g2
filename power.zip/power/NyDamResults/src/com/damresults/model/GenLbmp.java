package com.damresults.model;

import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.query.csv.NyisoDamLmpQuery;

public class GenLbmp {
	
	private HourlyCrossTab crossTab;
	//private String baseUrl = "http://localhost:8080/";
	private String baseUrl = "http://mis.nyiso.com/public/csv/damlbmp/";
	
	public GenLbmp(){
		crossTab = new HourlyCrossTab();
	}
	
	public boolean download(String dy) {
		
		try {
			
			NyisoDamLmpQuery nydam = 
					new NyisoDamLmpQuery(baseUrl+dy+"damlbmp_gen.csv");
			
			if (nydam.query()) {
				
				crossTab.addHeader("Node");
				crossTab.addHeader("PEAK");
				crossTab.addHeader("OFF");
				crossTab.addHeader("ATC");
				
				LocalDate date = LocalDate.parse(dy,
						DateTimeFormat.forPattern("yyyyMMdd"));
				
				DateTime start = date.toDateTimeAtStartOfDay();
				DateTime end = start.plusDays(1);
				
				while (start.isBefore(end)) {
					
					int hourB = start.getHourOfDay();
					int hourE = hourB + 1;

					crossTab.addHeader(""+hourE);
					start = start.plusHours(1);
				}
											
				HashMap<String, NyisoHourlyPriceSet> hm = nydam.getLbmpMap();
				
				for(String key: hm.keySet()) {
					
					String[] rowData = 
							new String[crossTab.getColHeaders().length];
					
					NyisoHourlyPriceSet nyps2 = hm.get(key);
					
					rowData[0] =  nyps2.getName();
					rowData[1] =  nyps2.get7x16Price()+"";
					rowData[2] =  nyps2.get7x8Price()+"";
					rowData[3] =  nyps2.get7x24Price()+"";
					
					start= date.toDateTimeAtStartOfDay();
					end = start.plusDays(1);
					
					int r = 4;
					
					while (start.isBefore(end)) {
						
						rowData[r]= nyps2.getHourlyPrice(start)+"";
					
						start = start.plusHours(1);
						r++;
					}
					
					crossTab.addDataRow(rowData);
					
				}
			}
			else {
				return false;
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	public HourlyCrossTab getCrossTab(){
		return crossTab;
	}

}
