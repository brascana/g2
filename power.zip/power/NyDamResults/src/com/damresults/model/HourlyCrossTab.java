package com.damresults.model;

import java.util.ArrayList;
import java.util.Arrays;

public class HourlyCrossTab {

	private ArrayList<String> columnHeaders;
	private ArrayList<String[]> data;
	public ArrayList<String> hours;
	

	public HourlyCrossTab() {
		columnHeaders = new ArrayList<String>();
		data = new ArrayList<String[]>();
		hours = new ArrayList<String>();
	}
	public void addHour(String hr) {
		hours.add(hr);
	}

	public void setHeaderByPos(int pos, String header) {
		columnHeaders.add(pos, header);
	}

	public void addHeader(String header) {
		columnHeaders.add(header);
	}
	
	public void addDataRow(String[] row){
		data.add(row);
	}
	
	public void addDataRowByPos(int pos, String[] row){
		data.add(pos,row);
	}
	
	public void setData(String[][] d){
		data = new ArrayList<String[]>(Arrays.asList(d));
	}
	
	public String[] getColHeaders(){
		
		 ArrayList<String> cH = columnHeaders;

		String[] headersArray = 
				cH.toArray(
				new String[cH.size()]);
		
		return headersArray;
	}
	
	public String[][] toTableArray() {
		String[][] dataArray = 
				new String[data.size()][columnHeaders.size()];
		
		return dataArray;
	}	
	public ArrayList<String[]> getTableData() {
		return data;
	}


}
