package com.damresults.model;

import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

import com.powerlib.ancillary.NyisoHourlyAncillary;
import com.powerlib.query.csv.NyisoDamAncillaryQuery;

public class Ancillary {
	
	private HourlyCrossTab crossTab;
	private String baseUrl = "http://mis.nyiso.com/public/csv/damasp/";
	
	public Ancillary(){
		crossTab = new HourlyCrossTab();
	}
	
	public boolean download(String dy) {
		
		try {
			
			NyisoDamAncillaryQuery nydam =
					new NyisoDamAncillaryQuery(baseUrl+dy+"damasp.csv");
			
			if (nydam.query()) {
				
				crossTab.addHeader("Product");
				
				LocalDate date = LocalDate.parse(dy,
						DateTimeFormat.forPattern("yyyyMMdd"));
				
				DateTime start = date.toDateTimeAtStartOfDay();
				DateTime end = start.plusDays(1);
				
				while (start.isBefore(end)) {
					
					int hourB = start.getHourOfDay();
					int hourE = hourB + 1;

					crossTab.addHeader(""+hourE);
					start = start.plusHours(1);
				}
				
				addData(nydam.getSE10SMap(),dy);
				addData(nydam.getSE10NSMap(),dy);
				addData(nydam.getSE30ORMap(),dy);
							
				addData(nydam.getE10SMap(),dy);
				addData(nydam.getE10NSMap(),dy);
				addData(nydam.getE30ORMap(),dy);
				addData(nydam.getERegMap(),dy);
				
				addData(nydam.getW10SMap(),dy);
				addData(nydam.getW10NSMap(),dy);
				addData(nydam.getW30ORMap(),dy);
				addData(nydam.getWRegMap(),dy);
		
				
			}
			else {
				return false;
				//System.out.println("TEST");
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	public HourlyCrossTab getCrossTab(){
		return crossTab;
	}
	
	private void addData(HashMap<String, NyisoHourlyAncillary> map, String dy) {
		
		LocalDate date = LocalDate.parse(dy,
				DateTimeFormat.forPattern("yyyyMMdd"));
		
		DateTime start = date.toDateTimeAtStartOfDay();
		DateTime end = start.plusDays(1);
		
		for(String key: map.keySet()) {
			
			String[] rowData = 
					new String[crossTab.getColHeaders().length];
			
			NyisoHourlyAncillary nyac = map.get(key);
			
			rowData[0] =  nyac.getProduct();

			start= date.toDateTimeAtStartOfDay();
			end = start.plusDays(1);
			
			int r = 1;
			
			
			while (start.isBefore(end)) {
				

				if(nyac.containsHour(start)){
					rowData[r]= nyac.getHourlyPrice(start)+"";
				}
				else {
					rowData[r]= "";
				}
							
				start = start.plusHours(1);
				r++;
			}
			
			crossTab.addDataRow(rowData);
			
		}
		
	}

}