package com.damresults.settings;

public class DamLbmpSettings {
	
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getSink() {
		return sink;
	}
	public void setSink(String sink) {
		this.sink = sink;
	}
	public String getSourcePtid() {
		return sourcePtid;
	}
	public void setSourcePtid(String sourcePtid) {
		this.sourcePtid = sourcePtid;
	}
	public String getSinkPtid() {
		return sinkPtid;
	}
	public void setSinkPtid(String sinkPtid) {
		this.sinkPtid = sinkPtid;
	}
	private String header;
	private String type;
	private String sourcePtid;
	private String source;
	private String sinkPtid;
	private String sink;
	
}
