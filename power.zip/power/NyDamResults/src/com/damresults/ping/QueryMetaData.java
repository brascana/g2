package com.damresults.ping;


public class QueryMetaData {
	
	private String name = "";
	private String url="";
	private long frequency =1000;
	private String start ="09:25";
	private boolean found = false;
	private String status ="idle";
	private String lastUpdate="N/A";
	
	
	public QueryMetaData(){
	}
	
	public String getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(String lup){
		lastUpdate = lup;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String s){
		status = s;
	}

	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public long getFrequency() {
		return frequency;
	}
	public void setFrequency(long frequency) {
		this.frequency = frequency;
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public boolean isFound() {
		return found;
	}
	public void setFound(boolean found) {
		this.found = found;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
		
}
