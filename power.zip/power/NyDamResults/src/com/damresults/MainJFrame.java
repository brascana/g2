package com.damresults;

import java.awt.Container;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.joda.time.DateTime;


import com.damresults.model.Ancillary;
import com.damresults.model.AtcTtc;
import com.damresults.model.DailyEnergy;
import com.damresults.model.GenLbmp;
import com.damresults.model.LimitingConstraint;
import com.damresults.model.ZonalLbmp;
import com.damresults.ping.QueryMetaData;
import com.damresults.ui.dialog.AncillaryPanel;
import com.damresults.ui.dialog.AtcTtcPanel;
import com.damresults.ui.dialog.DailyEnergyDniPanel;
import com.damresults.ui.dialog.GenLbmpPanel;
import com.damresults.ui.dialog.LimitingConstraintPanel;
import com.damresults.ui.dialog.StatusPanel;
import com.damresults.ui.dialog.ZonalLbmpPanel;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author rgillis1
 */
public class MainJFrame extends javax.swing.JFrame {


	private static final long serialVersionUID = -4214925935009314582L;

	private static final int QUERYTHREADS = 7;

	static Hashtable<String, QueryMetaData> metaTable = 
			new Hashtable<String, QueryMetaData>();

	static Set<String> linkedQueue = new LinkedHashSet<>();

	
	private static AtcTtcPanel atcTtcPanel;
	private static DailyEnergyDniPanel dniPanel;
	private static LimitingConstraintPanel lcPanel;
	private static ZonalLbmpPanel zonalPanel;
	private static AncillaryPanel ancPanel;
	private static GenLbmpPanel genPanel;
	private static StatusPanel statusPanel;

	private static javax.swing.JTabbedPane jTabbedPane1;

	private static Container contentPane;	

	private static javax.swing.JButton genLmpBtn;
	private static javax.swing.JButton genLossBtn;
	private static javax.swing.JButton genCongBtn;


	private static String dyFormat = "";

	public MainJFrame() {
		initComponents();
	}

	private void initComponents() {

		atcTtcPanel = new AtcTtcPanel();
		dniPanel = new DailyEnergyDniPanel();
		lcPanel = new LimitingConstraintPanel();
		zonalPanel = new ZonalLbmpPanel();
		ancPanel = new AncillaryPanel();
		genPanel = new GenLbmpPanel();
		statusPanel = new StatusPanel();

		jTabbedPane1 = new javax.swing.JTabbedPane();

		genLmpBtn = new javax.swing.JButton();
		genLossBtn = new javax.swing.JButton();
		genCongBtn = new javax.swing.JButton();

		genLmpBtn.setText("Lmp");
		genLossBtn.setText("Loss");
		genCongBtn.setText("Cong");

		contentPane = getContentPane();

		setDefaultCloseOperation(
				javax.swing.WindowConstants.EXIT_ON_CLOSE);
		
		setTitle("DAM Alert Tool");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				contentPane);
		contentPane.setLayout(layout);

		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jTabbedPane1));
		
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jTabbedPane1));

		setSize(1500, 800);

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);

		dyFormat = dateFormat.format(cal.getTime());

		setTitle("DAM Alert Tool - " + dyFormat);
		setVisible(true);
		
		addMetaData("TTC",
				    "http://mis.nyiso.com/public/csv/atc_ttc/" + dyFormat+ "atc_ttc.csv", 5000, "9:30");

		addMetaData("Dam LBMP", "http://mis.nyiso.com/public/csv/damlbmp/"
				+ dyFormat + "damlbmp_zone.csv", 1000, "9:20");

		addMetaData("Gen LBMP", "" + "http://mis.nyiso.com/public/csv/damlbmp/"
				+ dyFormat + "damlbmp_gen.csv", 1000, "9:20");

		addMetaData("Limiting Constraints",
				"http://mis.nyiso.com/public/csv/DAMLimitingConstraints/"
						+ dyFormat + "DAMLimitingConstraints.csv", 5000, "9:30");

		addMetaData("Ancillary", "http://mis.nyiso.com/public/csv/damasp/"
				+ dyFormat + "damasp.csv", 5000, "9:25");

		addMetaData("Daily Energy",
				"http://mis.nyiso.com/public/csv/damenergy/" + dyFormat
						+ "DAM_energy_rep.csv", 5000, "9:30");
		
		jTabbedPane1.addTab("Status", statusPanel);
		
	}

	public static void main(String args[]) {

		final ExecutorService executor = Executors
				.newFixedThreadPool(QUERYTHREADS);
		
		
		try {

			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}

		} catch (Exception e) {

		}

		// javax.swing.SwingUtilities.invokeLater(new Runnable() {
		java.awt.EventQueue.invokeLater(new Runnable() {
			Runnable worker = null;

			public void run() {

				new MainJFrame();

				Map<String, QueryMetaData> map = metaTable;

				Iterator<Entry<String, QueryMetaData>> it = map.entrySet()
						.iterator();

				while (it.hasNext()) {
					Entry<String, QueryMetaData> entry = it.next();

					if (!linkedQueue.contains(entry.getKey())) {

						linkedQueue.add(entry.getKey());
						QueryMetaData md = entry.getValue();

						worker = new MyRunnable(md);
						executor.execute(worker);

					} else {
					}

				}

			}
		});
	}
	public void addMetaData(String n, String u, long f, String t) {

		QueryMetaData md = new QueryMetaData();
		md.setName(n);
		md.setUrl(u);
		md.setStart(t);
		md.setFrequency(f);

		metaTable.put(md.getName(), md);

	}
	public synchronized static void loadZonalLbmp() {

		ZonalLbmp zLbmp = new ZonalLbmp();

		zLbmp.getSettings();

		if (zLbmp.download(dyFormat)) {

			TableModel tableModel = new DefaultTableModel(
					zLbmp.getTableArray(), zLbmp.getColumns());

			zonalPanel.updateTable(tableModel);
			zonalPanel.refreshZonalTable();

			jTabbedPane1.addTab("Zonal LBMP", zonalPanel);

		} else {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			loadZonalLbmp();
		}

	}
	public static void loadGenLbmp() {

		GenLbmp gLbmp = new GenLbmp();

		Thread.currentThread().setPriority(Thread.MIN_PRIORITY);

		if (gLbmp.download(dyFormat)) {

			genPanel.updateTable(gLbmp);
			genPanel.refreshGenTable();

			jTabbedPane1.addTab("Gen LBMP", genPanel);

		} else {

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			loadGenLbmp();
		}

	}
	public synchronized static void loadLC() {

		LimitingConstraint lc = new LimitingConstraint();

		if (lc.download(dyFormat)) {

			System.out.println("adding.. LC");

			DefaultTableModel tableModel = new DefaultTableModel(lc
					.getCrossTab().getColHeaders(), 0);

			ArrayList<String[]> tab = lc.getCrossTab().getTableData();

			lcPanel.updateTable(tableModel, tab);
			lcPanel.refreshLcTable();

			jTabbedPane1.addTab("Limiting Constraint", lcPanel);

		} else {

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			loadLC();
		}

	}
	/*public synchronized static void loadAC() {

		Ancillary ac = new Ancillary();

		if (ac.download(dyFormat)) {

			DefaultTableModel tableModel = new DefaultTableModel(ac
					.getCrossTab().getColHeaders(), 0);

			ArrayList<String[]> tab = ac.getCrossTab().getTableData();

			ancPanel.updateTable(tableModel, tab);
			ancPanel.refreshAncTable();
			jTabbedPane1.addTab("Ancillary", ancPanel);

		} else {
			loadAC();
		}
	}*/
	public synchronized static void loadDE() {

		DailyEnergy de = new DailyEnergy();

		if (de.download(dyFormat)) {

			DefaultTableModel tableModel = new DefaultTableModel(de
					.getCrossTab().getColHeaders(), 0);

			ArrayList<String[]> tab = de.getCrossTab().getTableData();

			dniPanel.updateTableData(tableModel, tab);
			dniPanel.refreshDniTable();
			dniPanel.refreshImportTable();
			dniPanel.refreshExportTable();

			jTabbedPane1.addTab("Daily Energy (DNI)", dniPanel);

		} else {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}

			loadDE();
		}
	}
	public synchronized static void loadAtcTtc() {
		AtcTtc at = new AtcTtc();
		
		if(at.download(dyFormat)) {
			
			DefaultTableModel tableModel = new DefaultTableModel(at
					.getCrossTab().getColHeaders(), 0);
			
			ArrayList<String[]> tab = at.getCrossTab().getTableData();
			
			atcTtcPanel.updateTableData(tableModel, tab);
			atcTtcPanel.refreshAtcTable();
			jTabbedPane1.addTab("ATC", atcTtcPanel);
			
		}
		
	}
	public static class MyRunnable implements Runnable {

		private final QueryMetaData data;

		MyRunnable(QueryMetaData md) {
			this.data = md;
		}

		@Override
		public void run() {

			Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
			statusPanel.updateStatusTable(metaTable);

			String[] hrStr = data.getStart().split(":");
			int hr = Integer.parseInt(hrStr[0]);
			int mn = Integer.parseInt(hrStr[1]);
					
			DateTime startTime = new DateTime().withHourOfDay(hr)
					.withMinuteOfHour(mn);

			int code = 0;

			while (true) {

				DateTime now = new DateTime();

				if (now.isAfter(startTime)) {
					try {

						data.setStatus("searching...");
						data.setLastUpdate(now.toString("HH:mm:ss"));
						statusPanel.updateStatusTable(metaTable);
						
						URL siteURL = new URL(data.getUrl());

						HttpURLConnection connection = (HttpURLConnection) siteURL
								.openConnection();

						connection.setRequestMethod("GET");
						connection.connect();

						code = connection.getResponseCode();

						if (code == 200) {
							data.setStatus("found...");

							if (data.getName().equals("Dam LBMP")) {
								data.setStatus("downloading...");
								loadZonalLbmp();
								data.setStatus("finished");

							} else if (data.getName().equals("Gen LBMP")) {
								data.setStatus("downloading...");
								loadGenLbmp();
								data.setStatus("finished");

							} else if (data.getName().equals(
									"Limiting Constraints")) {
								data.setStatus("downloading...");
								loadLC();
								data.setStatus("finished");

							} /*else if (data.getName().equals("Ancillary")) {
								data.setStatus("downloading...");
								loadAC();
								data.setStatus("finished");

							} */ else if (data.getName().equals("Daily Energy")) {
								data.setStatus("downloading...");
								loadDE();
								data.setStatus("finished");
							} else if (data.getName().equals("TTC")) {
								data.setStatus("downloading...");
								loadAtcTtc();
								data.setStatus("finished");
							}
							
							metaTable.put(data.getName(), data);
							statusPanel.updateStatusTable(metaTable);
							//metaTable.remove(data.getName());
							linkedQueue.remove(data.getName());
							data.setFound(true);

							break;
						} else {
							data.setStatus("sleeping...");
							metaTable.put(data.getName(), data);
							statusPanel.updateStatusTable(metaTable);
							Thread.sleep(data.getFrequency());
						}

					} catch (Exception e) {

					}

				} else {

				}

			}

		}

	}

}
