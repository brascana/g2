package tablesaw_nyiso;

import java.io.InputStream;
import java.net.URL;

import com.github.lwhite1.tablesaw.api.ColumnType;
import com.github.lwhite1.tablesaw.api.Table;

public class Test {
	
	public static void main(String[] args) {
		
		//Time Stamp	Name	PTID	LBMP ($/MWHr)	Marginal Cost Losses ($/MWHr)	Marginal Cost Congestion ($/MWHr)

		ColumnType[] types = 
		{
			ColumnType.CATEGORY,
			ColumnType.CATEGORY,
			ColumnType.CATEGORY,
			ColumnType.FLOAT,
			ColumnType.FLOAT,
			ColumnType.FLOAT 
		};
		
		String dateStr ="20160725";
		String location = NyisoUtil.getRtZonalLbmpUrl(dateStr);
		Table table;
		try (InputStream input = new URL(location).openStream()) {
		  table = Table.createFromStream(types, true, ',', input, "test").sortOn("Name");
		  
		  //Table tab2 = CrossTab.(table, table.categoryColumn("Time Stamp"), table.shortColumn("Name"));
		  Table pt = NyisoPivotTab.createPivot(table, table.column("Time Stamp"), table.column("Name"),table.column("LBMP ($/MWHr)"));		  
		  //System.out.print(pt.print());
		  
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
	public static void parseDate(String dateStr){
		
	}
}
	
