package tablesaw_nyiso;

public class NyisoUtil {
	public static String getRtZonalLbmpUrl(String dateStr) {
		return String.format("http://mis.nyiso.com/public/csv/realtime/%srealtime_zone.csv", dateStr);
	}
}
