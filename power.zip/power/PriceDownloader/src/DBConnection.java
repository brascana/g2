import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnection {
	
	private static String DB_URL = "jdbc:mysql://localhost:3306/power";
	private static String DB_USERNAME = "root";
	private static String DB_PASSWORD = "";
	
	private static Connection connection =null;
	
	public void connect() {
		connection =null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			connection = DriverManager
			.getConnection(DB_URL,DB_USERNAME,DB_PASSWORD);
			connection.setAutoCommit(false);
	 
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
		}
	}
	public void close() throws SQLException{
		if (connection != null) 
			connection.close();
	}
	public Connection getConnection(){
		return connection;
	}

	

}
