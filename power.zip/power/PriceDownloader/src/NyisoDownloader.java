import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.powerlib.util.HttpFileDownload;

public class NyisoDownloader {

	private int NYISO_HISTORY_DAYS = -8;

	private LocalDate startDate;
	private LocalDate endDate;

	public NyisoDownloader(LocalDate s, LocalDate e) {
		startDate =s;
		endDate = e;
	}

	public void download(String baseFolder, String baseUrl, String baseFileName) throws IOException {

		HttpFileDownload downloader = new HttpFileDownload();

		DateTime now = new DateTime();
		LocalDate last_day = now.toLocalDate().plusDays(NYISO_HISTORY_DAYS);

		if (startDate.isBefore(last_day)) {
			
			
			for (LocalDate date = startDate; date.isBefore(endDate) || date.isEqual(endDate); date = date.plusMonths(1)) {

				DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyMMdd");
				
				String str = fmt.print(date.withDayOfMonth(1));
				System.out.println(baseFolder + str + baseFileName+ "_csv.zip");
				

				File file = new File(baseFolder + str + baseFileName+ "_csv.zip");
				downloader.downloadToFile(baseUrl + str + baseFileName+ "_csv.zip", file);
				decompress(file.getAbsolutePath(),baseFolder);
				//Files.delete(file.toPath());
			}

		}

		else {

			for (LocalDate date = startDate; date.isBefore(endDate) || date.isEqual(endDate); date = date.plusDays(1)) {

				DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyMMdd");
				String str = fmt.print(date);

				File file = new File(baseFolder + str + baseFileName + ".csv");
				downloader.downloadToFile(baseUrl + str + baseFileName + ".csv", file);
			}

		}

	}
	public void decompress(String zipFile, String outputFolder) {
		
		byte[] buffer = new byte[1024];
		
		try {
			//File folder = new File(outputFolder);
			ZipInputStream zis = 
		    		new ZipInputStream(new FileInputStream(zipFile));
			
			ZipEntry ze = zis.getNextEntry();
			
			while(ze!=null){
				
				String fileName = ze.getName();
		        File newFile = new File(outputFolder + File.separator + fileName);
		        
		        System.out.println("file unzip : "+ newFile.getAbsoluteFile());
		        
		        new File(newFile.getParent()).mkdirs();
		        
	            FileOutputStream fos = new FileOutputStream(newFile);  
	            
	            int len;
	            while ((len = zis.read(buffer)) > 0) {
	       		fos.write(buffer, 0, len);
	            }
	 
	            fos.close();   
	            ze = zis.getNextEntry();
	    	}
							
			zis.closeEntry();
	    	zis.close();
	    	
		}catch(IOException ex){
		       ex.printStackTrace(); 
	    }
		
	}



}
