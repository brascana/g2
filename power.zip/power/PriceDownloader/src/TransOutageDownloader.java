import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.powerlib.powergrid.NyisoTransOut;
import com.powerlib.query.csv.NyisoTransOutQuery;


public class TransOutageDownloader {
	
	private String FOLDER = "D://power_download//";
	private String dateLookupSQL = "SELECT DATE FROM NYISO_DA_SCH_OUTAGES_REF ORDER BY DATE DESC LIMIT 1";
	private String baseURL = "http://mis.nyiso.com//public//csv//outSched//";
	private String baseFileName = "outSched";
	private LocalDate start = new LocalDate("2005-01-01");
	private LocalDate end = new LocalDate();
	private DBConnection dbc;
	
	public void GET() {
			
		dbc = new DBConnection();
		dbc.connect();
		
		try {
			getLatestDate();
			
			if(start.isBefore(end) || start.isEqual(end)) {
				NyisoDownloader nyloader = new NyisoDownloader(start,end);
				nyloader.download(FOLDER, baseURL, baseFileName);
				readInsertCSVtoDB();
			}
			else {
				System.out.println("no data to update");
			}		
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		if (dbc.getConnection() != null ) {
			try {
				dbc.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	public void readInsertCSVtoDB(){
		
		for (LocalDate date = start; date.isBefore(end) || date.isEqual(end); date = date.plusDays(1)) {
			
			DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyMMdd");
			String str = fmt.print(date);
			
			System.out.println(fmt.print(date));
			NyisoTransOutQuery query = new NyisoTransOutQuery(FOLDER+str+baseFileName+".csv");
			
			
			query.readCSVFile();
			
			HashMap<String, NyisoTransOut> outageMap = query.getOutageMap();

			
			String sql="";
			
			for(String key: outageMap.keySet()) {
					
				NyisoTransOut outageSet = outageMap.get(key);

						
				DateTime s = date.toDateTimeAtStartOfDay();
				s.withZone(DateTimeZone.forID("America/New_York"));
				
							
					sql="INSERT INTO NYISO_DA_SCH_OUTAGES(DATE,PTID,NAME,SCH_OUT,SCH_IN) VALUES(?,?,?,?,?)";
					PreparedStatement preparedStatement = null;
					
					try {																												
							
							preparedStatement = dbc.getConnection().prepareStatement(sql);
							
							preparedStatement.setTimestamp(1, new java.sql.Timestamp(s.toDate().getTime()));
							preparedStatement.setString(2, outageSet.getPtid());
							preparedStatement.setString(3, outageSet.getEquipmentName());
							
							if(outageSet.getDateOut() !=null)
								preparedStatement.setTimestamp(4,new java.sql.Timestamp(outageSet.getDateOut().toDate().getTime()));
							else
								preparedStatement.setNull(4, java.sql.Types.DATE);
							
							if(outageSet.getDatIn() !=null)
								preparedStatement.setTimestamp(5,new java.sql.Timestamp(outageSet.getDatIn().toDate().getTime()));
							else
								preparedStatement.setNull(5, java.sql.Types.DATE);
							
							preparedStatement.executeUpdate();
							
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}finally {
						 
						if (preparedStatement != null) {
							try {
								preparedStatement.close();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
						}
					}
				
				
			}
			try {
				dbc.getConnection().commit();
				String updateRefTable = "INSERT INTO NYISO_DA_SCH_OUTAGES_REF(DATE) VALUES(?)";
				PreparedStatement pStmtRef = null;
				
				pStmtRef= dbc.getConnection().prepareStatement(updateRefTable);
				pStmtRef.setDate(1, new java.sql.Date(date.toDate().getTime()));
				pStmtRef.executeUpdate();	
				
				dbc.getConnection().commit();
				
				System.out.println("nyiso_load commit:"+str);
			} catch (SQLException e1) {
				e1.printStackTrace();
				try {
					dbc.getConnection().rollback();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	public void getLatestDate() throws SQLException { 
		java.sql.Statement stmt = null;
		try{
			stmt = dbc.getConnection().createStatement();
			java.sql.ResultSet rs = stmt.executeQuery(dateLookupSQL);
			while (rs.next()) {
				String latestDate = rs.getDate("date").toString();
				
				start =new LocalDate(latestDate).plusDays(1);
				
			}
		} catch (SQLException e ) {
	        
	    } finally {
	        if (stmt != null) { stmt.close(); }
	    }
	}
}
