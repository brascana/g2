import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.powerlib.load.NyisoHourlyLoad;
import com.powerlib.query.csv.NyisoHourlyLoadQuery;
import com.powerlib.time.NyisoCalendar;


public class LoadDownloader {
	
	private String FOLDER = "D://power_download//";
	private String dateLookupSQL = "SELECT DATE FROM NYISO_HOURLY_LOAD_REF ORDER BY DATE DESC LIMIT 1";
	private String baseURL = "http://mis.nyiso.com//public//csv//palIntegrated//";
	private String baseFileName = "palIntegrated";
	private NyisoCalendar nyCal;
	private LocalDate start = new LocalDate("2006-01-01");
	private LocalDate end = new LocalDate().plusDays(-1);
	private DBConnection dbc;
		
	public void GET() {
		
		nyCal = new NyisoCalendar();
		
		dbc = new DBConnection();
		dbc.connect();
		
		try {
			
			getLatestDate();
			
			if(start.isBefore(end) || start.isEqual(end)) {
				NyisoDownloader nyloader = new NyisoDownloader(start,end);
				nyloader.download(FOLDER, baseURL, baseFileName);
				readInsertCSVtoDB();
			}
			else {
				System.out.println("no data to update");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		if (dbc.getConnection() != null ) {
			try {
				dbc.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	public void readInsertCSVtoDB(){
		
		for (LocalDate date = start; date.isBefore(end) || date.isEqual(end); date = date.plusDays(1)) {
			
			DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyMMdd");
			String str = fmt.print(date);
			
			NyisoHourlyLoadQuery query = new NyisoHourlyLoadQuery(FOLDER+str+baseFileName+".csv");
			
			
			query.readCSVFile();
			
			HashMap<String, NyisoHourlyLoad> loadMap = query.getLoadMap();

			
			String sql="";
			
			for(String key: loadMap.keySet()) {
					
				NyisoHourlyLoad loadSet = loadMap.get(key);

						
				DateTime s = date.toDateTimeAtStartOfDay();
				s.withZone(DateTimeZone.forID("America/New_York"));
				
				DateTime e = s.plusDays(1);
				
				while (s.isBefore(e)) {
					
					int hourB = s.getHourOfDay();
					int hourE = hourB + 1;
							
					sql="INSERT INTO NYISO_HOURLY_LOAD(NAME,PTID,DATE,HE,HR_LOAD,IS_PEAK) VALUES(?,?,?,?,?,?)";
					PreparedStatement preparedStatement = null;
					
					try {
										
						if(loadSet.containsHour(s)) {																			
							
							preparedStatement = dbc.getConnection().prepareStatement(sql);
							
							preparedStatement.setString(1, loadSet.getZone());
							preparedStatement.setString(2, loadSet.getPtid());
							preparedStatement.setTimestamp(3, new java.sql.Timestamp(s.toDate().getTime()));
							preparedStatement.setInt(4, hourE);
							preparedStatement.setDouble(5, loadSet.getHourlyLoad(s));

							
							if(nyCal.isPeakDay(s) && hourE > 7 && hourE <24) {
								
								preparedStatement.setString(6, "Y");
							}
							else {
								preparedStatement.setString(6, "N");
							}
									
							preparedStatement.executeUpdate();
							
						}else{
							
						}
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}finally {
						 
						if (preparedStatement != null) {
							try {
								preparedStatement.close();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
						}
					}
					s = s.plusHours(1);
				}
				
				
			}
			try {
				dbc.getConnection().commit();
				String updateRefTable = "INSERT INTO NYISO_HOURLY_LOAD_REF(DATE) VALUES(?)";
				PreparedStatement pStmtRef = null;
				
				pStmtRef= dbc.getConnection().prepareStatement(updateRefTable);
				pStmtRef.setDate(1, new java.sql.Date(date.toDate().getTime()));
				pStmtRef.executeUpdate();	
				
				dbc.getConnection().commit();
				
				System.out.println("nyiso_load commit:"+str);
			} catch (SQLException e1) {
				e1.printStackTrace();
				try {
					dbc.getConnection().rollback();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	public void getLatestDate() throws SQLException { 
		java.sql.Statement stmt = null;
		try{
			stmt = dbc.getConnection().createStatement();
			java.sql.ResultSet rs = stmt.executeQuery(dateLookupSQL);
			while (rs.next()) {
				String latestDate = rs.getDate("date").toString();
				
				start =new LocalDate(latestDate).plusDays(1);
				
			}
		} catch (SQLException e ) {
	        
	    } finally {
	        if (stmt != null) { stmt.close(); }
	    }
	}
}
