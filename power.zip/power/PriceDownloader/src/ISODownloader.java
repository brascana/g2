
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.query.csv.NyisoDamLmpQuery;
import com.powerlib.time.NyisoCalendar;


public class ISODownloader {
	
	private static NyisoCalendar nyCal;
	private static String FOLDER = "D://power_download//";
	
	private static String BASE_URL = "http://mis.nyiso.com//public//csv//damlbmp//";
	private static String BASE_FILE_NAME = "damlbmp_gen";
	private static String DATE_SELECT_SQL = "SELECT DATE FROM NYISO_DA_LBMP_REF WHERE TYPE LIKE 'gen' ORDER BY DATE DESC LIMIT 1";
	
	
	private static DBConnection dbc;
	private static boolean isConnected = false;
	private static LocalDate start = new LocalDate("2015-04-23");
	private static LocalDate end = new LocalDate("2015-11-28");
	
	public static void main(String[] args) {
			
		NyisoDownloader nyloader = new NyisoDownloader(start,end);
		
		nyCal = new NyisoCalendar();
		
		dbc = new DBConnection();
		dbc.connect();
		
		if (dbc.getConnection() != null)
			isConnected =true;

		try {
			getLatestDate();
			
			if(start.isBefore(end) || start.isEqual(end)){
				nyloader.download(FOLDER, BASE_URL, BASE_FILE_NAME);
				readInsertCSVtoDB();
			}
			else {
				System.out.println("no data to update");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}	
		
		
		if (isConnected) {
			try {
				dbc.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public static void readInsertCSVtoDB(){
		
		for (LocalDate date = start; date.isBefore(end) || date.isEqual(end); date = date.plusDays(1)) {
			
			DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyMMdd");
			String str = fmt.print(date);
			
			NyisoDamLmpQuery query = new NyisoDamLmpQuery(FOLDER+str+BASE_FILE_NAME+".csv");
			
			query.readCSVFile();
			
			HashMap<String, NyisoHourlyPriceSet> lbmpMap = query.getLbmpMap();
			HashMap<String, NyisoHourlyPriceSet> lossMap = query.getLossMap();
			HashMap<String, NyisoHourlyPriceSet> congMap = query.getCongMap();
			
			String sql="";
			
			for(String key: lbmpMap.keySet()) {
					
				NyisoHourlyPriceSet lbmpPs = lbmpMap.get(key);
				NyisoHourlyPriceSet lossPs = lossMap.get(key);
				NyisoHourlyPriceSet congPs = congMap.get(key);
						
				DateTime s = date.toDateTimeAtStartOfDay();
				s.withZone(DateTimeZone.forID("America/New_York"));
				
				DateTime e = s.plusDays(1);
				
				while (s.isBefore(e)) {
					
					int hourB = s.getHourOfDay();
					int hourE = hourB + 1;
							
					sql="INSERT INTO NYISO_DA_LBMP(PTID,DATE,HE,NAME,TYPE,LBMP,LOSS,CONG,IS_PEAK) VALUES(?,?,?,?,?,?,?,?,?)";
					PreparedStatement preparedStatement = null;
					
					try {
										
						if(lbmpPs.containsHour(s)) {																			
							
							preparedStatement = dbc.getConnection().prepareStatement(sql);
							
							preparedStatement.setString(1, lbmpPs.getPtid());
							preparedStatement.setTimestamp(2, new java.sql.Timestamp(s.toDate().getTime()));
							preparedStatement.setInt(3, hourE);
							preparedStatement.setString(4, lbmpPs.getName());
							preparedStatement.setString(5, "gen");
							preparedStatement.setDouble(6, lbmpPs.getHourlyPrice(s));	
							preparedStatement.setDouble(7, lossPs.getHourlyPrice(s));
							preparedStatement.setDouble(8, congPs.getHourlyPrice(s));
							
							if(nyCal.isPeakDay(s) && hourE > 7 && hourE <24) {
								
								preparedStatement.setString(9, "Y");
							}
							else {
								preparedStatement.setString(9, "N");
							}
									
							preparedStatement.executeUpdate();
							
						}else{
							
						}
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}finally {
						 
						if (preparedStatement != null) {
							try {
								preparedStatement.close();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
						}
					}
					s = s.plusHours(1);
				}			
			}
			try {
				dbc.getConnection().commit();
				String updateRefTable = "INSERT INTO NYISO_DA_LBMP_REF(DATE,TYPE) VALUES(?,?)";
				PreparedStatement pStmtRef = null;
				
				pStmtRef= dbc.getConnection().prepareStatement(updateRefTable);
				pStmtRef.setDate(1, new java.sql.Date(date.toDate().getTime()));
				pStmtRef.setString(2,"gen");
				pStmtRef.executeUpdate();	
				
				dbc.getConnection().commit();
				
				System.out.println("commit:"+str);
			} catch (SQLException e1) {
				e1.printStackTrace();
				try {
					dbc.getConnection().rollback();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	public static void getLatestDate() throws SQLException { 
		java.sql.Statement stmt = null;
		try{
			stmt = dbc.getConnection().createStatement();
			java.sql.ResultSet rs = stmt.executeQuery(DATE_SELECT_SQL);
			while (rs.next()) {
				String latestDate = rs.getDate("date").toString();
				
				start =new LocalDate(latestDate).plusDays(1);
				
			}
		} catch (SQLException e ) {
	        
	    } finally {
	        if (stmt != null) { stmt.close(); }
	    }
	}

}
