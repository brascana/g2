import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.query.csv.NyisoDamLmpQuery;
import com.powerlib.time.NyisoCalendar;


public class LmpDownloader {
	
	private String FOLDER = "D://power_download//";
	
	private String baseURL;
	private String baseTable;
	private NyisoCalendar nyCal;
	private String baseFileName;
	private String dateLookupSQL;
	private String type;
	private DBConnection dbc;
	private LocalDate start = new LocalDate("2005-01-01");
	private LocalDate end = new LocalDate();
	
	public void GET( String t, String mkt) {
		
		type = t.toLowerCase();
		boolean validated = validateInputs(t,mkt);
		
		if(validated) {
			
			nyCal = new NyisoCalendar();
			
			dbc = new DBConnection();
			dbc.connect();
			
			try {
				
				getLatestDate();
				
				if(start.isBefore(end) || start.isEqual(end)) {
					NyisoDownloader nyloader = new NyisoDownloader(start,end);
					nyloader.download(FOLDER, baseURL, baseFileName);
					readInsertCSVtoDB();
				}
				else {
					System.out.println("no data to update");
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(0);
			}
			
			if (dbc.getConnection() != null ) {
				try {
					dbc.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		


	}
	public void getLatestDate() throws SQLException { 
		java.sql.Statement stmt = null;
		try{
			stmt = dbc.getConnection().createStatement();
			java.sql.ResultSet rs = stmt.executeQuery(dateLookupSQL);
			while (rs.next()) {
				String latestDate = rs.getDate("date").toString();
				
				start =new LocalDate(latestDate).plusDays(1);
				
			}
		} catch (SQLException e ) {
	        
	    } finally {
	        if (stmt != null) { stmt.close(); }
	    }
	}
	public void readInsertCSVtoDB(){
		
		for (LocalDate date = start; date.isBefore(end) || date.isEqual(end); date = date.plusDays(1)) {
			
			DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyMMdd");
			String str = fmt.print(date);
			
			NyisoDamLmpQuery query = new NyisoDamLmpQuery(FOLDER+str+baseFileName+".csv");
			
			query.readCSVFile();
			
			HashMap<String, NyisoHourlyPriceSet> lbmpMap = query.getLbmpMap();
			HashMap<String, NyisoHourlyPriceSet> lossMap = query.getLossMap();
			HashMap<String, NyisoHourlyPriceSet> congMap = query.getCongMap();
			
			String sql="";
			
			for(String key: lbmpMap.keySet()) {
					
				NyisoHourlyPriceSet lbmpPs = lbmpMap.get(key);
				NyisoHourlyPriceSet lossPs = lossMap.get(key);
				NyisoHourlyPriceSet congPs = congMap.get(key);
						
				DateTime s = date.toDateTimeAtStartOfDay();
				s.withZone(DateTimeZone.forID("America/New_York"));
				
				DateTime e = s.plusDays(1);
				
				while (s.isBefore(e)) {
					
					int hourB = s.getHourOfDay();
					int hourE = hourB + 1;
							
					sql="INSERT INTO "+baseTable+"(PTID,DATE,HE,NAME,TYPE,LBMP,LOSS,CONG,IS_PEAK) VALUES(?,?,?,?,?,?,?,?,?)";
					PreparedStatement preparedStatement = null;
					
					try {
										
						if(lbmpPs.containsHour(s)) {																			
							
							preparedStatement = dbc.getConnection().prepareStatement(sql);
							
							preparedStatement.setString(1, lbmpPs.getPtid());
							preparedStatement.setTimestamp(2, new java.sql.Timestamp(s.toDate().getTime()));
							preparedStatement.setInt(3, hourE);
							preparedStatement.setString(4, lbmpPs.getName());
							preparedStatement.setString(5, type);
							preparedStatement.setDouble(6, lbmpPs.getHourlyPrice(s));	
							preparedStatement.setDouble(7, lossPs.getHourlyPrice(s));
							preparedStatement.setDouble(8, congPs.getHourlyPrice(s));
							
							if(nyCal.isPeakDay(s) && hourE > 7 && hourE <24) {
								
								preparedStatement.setString(9, "Y");
							}
							else {
								preparedStatement.setString(9, "N");
							}
									
							preparedStatement.executeUpdate();
							
						}else{
							
						}
						
					} catch (SQLException e1) {
						e1.printStackTrace();
					}finally {
						 
						if (preparedStatement != null) {
							try {
								preparedStatement.close();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
						}
					}
					s = s.plusHours(1);
				}
				
				
			}
			try {
				dbc.getConnection().commit();
				String updateRefTable = "INSERT INTO "+baseTable+"_REF(DATE,TYPE) VALUES(?,?)";
				PreparedStatement pStmtRef = null;
				
				pStmtRef= dbc.getConnection().prepareStatement(updateRefTable);
				pStmtRef.setDate(1, new java.sql.Date(date.toDate().getTime()));
				pStmtRef.setString(2,"gen");
				pStmtRef.executeUpdate();	
				
				dbc.getConnection().commit();
				
				System.out.println("commit:"+str);
			} catch (SQLException e1) {
				e1.printStackTrace();
				try {
					dbc.getConnection().rollback();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		}
	}
	boolean validateInputs(String t, String mkt){
		if(mkt.toLowerCase().contains("da")){ 	
			
			if(t.toLowerCase().contains("gen")) 	
				baseFileName = "damlbmp_gen";
			else if(t.toLowerCase().contains("zonal"))
				baseFileName = "damlbmp_zone";
			else
				return false;
			
			baseURL = "http://mis.nyiso.com//public//csv//damlbmp//";
			baseTable = "NYISO_DA_LBMP";
			dateLookupSQL = "SELECT DATE FROM "+baseTable+"_REF WHERE TYPE LIKE '"+t+"' ORDER BY DATE DESC LIMIT 1";
			
			
		}
		else if(mkt.toLowerCase().contains("rt")){
			
			if(t.toLowerCase().contains("gen")) 	
				baseFileName = "rtlbmp_gen";
			else if(t.toLowerCase().contains("zonal"))
				baseFileName = "rtlbmp_zone";
			else
				return false;
			
			baseURL = "http://mis.nyiso.com//public//csv//rtlbmp//damlbmp//";
			baseTable = "NYISO_RT_LBMP";
			dateLookupSQL = "SELECT DATE FROM "+baseTable+"_REF WHERE TYPE LIKE '"+t+"' ORDER BY DATE DESC LIMIT 1";
			
			
		}
		else {
			return false;
		}
		return true;
	}

}
