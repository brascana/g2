
public class MainClass {
	
	public static void main(String[] args) {
		
		LmpDownloader lmpD = new LmpDownloader();
		lmpD.GET("gen", "DA");
		lmpD.GET("zonal", "DA");
		
		LoadDownloader loadD = new LoadDownloader();
		loadD.GET();
		
		TransOutageDownloader transD = new TransOutageDownloader();
		transD.GET();
	}
	
}