package com.gquant.backtest;

import java.util.Hashtable;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;

public class Test1 {

	private static String filePath = "C://Users//rgillis1//Documents//stock_data.csv";
	private static double increaseTarget = 0.30;
	private static double decreaseTarget = -0.30;

	private static int beginHour = 10;
	private static int endHour = 14;

	private static CsvReader csvReader = null;
	
	private static Hashtable<DateTime,Double> spreadTable;
	 

	public static void main(String[] args) {
		spreadTable = new Hashtable<DateTime, Double>();
		parseCSV();
						
		LocalDate start = new LocalDate("2014-11-07");
		LocalDate end = new LocalDate("2015-05-13");

		//s.withZone(DateTimeZone.forID("America/New_York"));
		
		int count =0;
		int count2 =0;
		
		double cSum =0;
		double c2Sum=0;
		
		for (LocalDate date = start; date.isBefore(end) || date.isEqual(end); date = date.plusDays(1)) {
			
			DateTime s = date.toDateTimeAtStartOfDay();
			DateTime e = s.plusDays(1);
			
			s=s.plusHours(10);
			
			double open;
			boolean openPosition = false;
			
			if(spreadTable.containsKey(s)){
				
				open = spreadTable.get(s);
				
				double sellPrice=0;
				while (s.isBefore(e)) {
					s=s.plusMinutes(1);
					
					if(!openPosition){
						if(spreadTable.containsKey(s) && s.getHourOfDay() <= 13){
							
							double val = spreadTable.get(s);
							if (val - open > 0.50){
								
								sellPrice = val;
								
								openPosition = true;
							}
						}
					}
					else {
						if(spreadTable.containsKey(s)){
							double val = spreadTable.get(s);
							double diff = sellPrice - val;
							
						if(diff > .25 && s.getHourOfDay() <= 14){
							count++;
							System.out.println("TRUE");
							openPosition = false;
						}
						else if (s.getHourOfDay() >= 15){
							
							c2Sum += diff;
							openPosition = false;
							count2++;
							break;
							
						}
						}
					}
					
				}
			}	
			
		}
		
		System.out.println(count);
		System.out.println(count2);
		System.out.println(c2Sum);
		
	}

	public static void parseCSV() {

		try {
			csvReader = new CsvReader(filePath);
		} catch (Exception e) {
			System.out.println(e);
		}

		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {
					
					boolean skip = false;
					
					String timestamp = csvReader.get(0);

					DateTime dt = timestampToDateTime(timestamp);
									
					String close1Str = csvReader.get(3);
					String close2Str = csvReader.get(6);
					
					double close1=0;
					double close2=0;
					
					if(close1Str.length()<1)
						skip = true;
						
					if(close2Str.length()<1)
						skip = true;
						
					if(!skip) {
						
						
						close1 = Double.parseDouble(close1Str);
						close2 = Double.parseDouble(close2Str);
						
						double spread = close2-close1;
						
						spreadTable.put(dt, spread);

					}	
				}
				
			} catch (Exception e) {
				System.out.println("ERRORRRRRRRR:" + e);
			}
		}
		
	}
	private static DateTime timestampToDateTime(String time) {
		
		DateTimeFormatter dtf 
			= DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
		
		DateTime dt = dtf.parseDateTime(time);
		return(dt);
	}
	
	private class Trade {
		public DateTime tradeTime;
		public double volume;
		public double price;
	}

}
