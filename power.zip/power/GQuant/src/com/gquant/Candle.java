package com.gquant;

import java.io.Serializable;
import java.util.Date;

public class Candle implements Comparable<Candle>, Serializable {

	private static final long serialVersionUID = 1L;

	private String symbol;

	private Date date = new Date();

	private double openPrice;

	private double highPrice;

	private double lowPrice;

	private double closePrice;

	private double volume;

	public Candle() {
	}

	public Candle(String symbol, Date date, double open, double high,
			double low, double close, double volume) {
		super();
		this.symbol = symbol;
		this.date = date;
		this.openPrice = open;
		this.highPrice = high;
		this.lowPrice = low;
		this.closePrice = close;
		this.volume = volume;
	}

	public double getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(double open) {
		this.openPrice = open;
	}

	public double getHighPrice() {
		return highPrice;
	}

	public void setHighPrice(double high) {
		this.highPrice = high;
	}

	public double getLowPrice() {
		return lowPrice;
	}

	public void setLowPrice(double low) {
		this.lowPrice = low;
	}

	public double getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(double close) {
		this.closePrice = close;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date time) {
		this.date = time;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	@Override
	public String toString() {
		return String.format("%s [%.2f, %.2f, %.2f, %.2f] [%s]", symbol,
				openPrice, highPrice, lowPrice, closePrice, date);
	}

	@Override
	public int compareTo(Candle c) {
		return this.getDate().compareTo(c.getDate());
	}

}