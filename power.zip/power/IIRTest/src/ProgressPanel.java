public class ProgressPanel extends javax.swing.JPanel {

    /**
	 * 
	 */
	private static final long serialVersionUID = -7849970308512311018L;
	/**
     * Creates new form ProgressPanel
     */
    public ProgressPanel() {
        initComponents();
    }
                        
    private void initComponents() {

        progressBar = new javax.swing.JProgressBar();
        statusLbl = new javax.swing.JLabel();

        statusLbl.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        statusLbl.setText("Downloading");
        statusLbl.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 306, Short.MAX_VALUE)
                .addComponent(statusLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(progressBar, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
            .addComponent(statusLbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }                     

    public javax.swing.JLabel getStatusLbl() {
		return statusLbl;
	}

	public void setStatusLbl(javax.swing.JLabel statusLbl) {
		this.statusLbl = statusLbl;
	}

	public javax.swing.JProgressBar getProgressBar() {
		return progressBar;
	}

	public void setProgressBar(javax.swing.JProgressBar progressBar) {
		this.progressBar = progressBar;
	}
	private javax.swing.JProgressBar progressBar;
	private javax.swing.JLabel statusLbl;               
}
