import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.DefaultRowSorter;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import com.csvreader.CsvReader;



public class MainFrame extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -467287079531629119L;
	/**
	 * 
	 */

	
	private static final String CSV_COLUMN_NAME_UNIT_NAME = "UnitName";
	private static final String CSV_COLUMN_NAME_OUTPUT_CAPACITY = "OutputCapacity";
	private static final String CSV_COLUMN_NAME_PRIMARY_FUEL = "PrimaryFuel";
	private static final String CSV_COLUMN_NAME_START_DATE = "StartDate";
	private static final String CSV_COLUMN_NAME_END_DATE = "EndDate";
	private static final String CSV_COLUMN_NAME_CAP_OFFLINE = "CAP_OFFLINE";
	private static final String CSV_COLUMN_NAME_ISO = "ISORTOREGION";
	private static final String[] fixedColumnNames = { CSV_COLUMN_NAME_UNIT_NAME, CSV_COLUMN_NAME_PRIMARY_FUEL, CSV_COLUMN_NAME_OUTPUT_CAPACITY, CSV_COLUMN_NAME_ISO };

	private static final int DAY_COUNT_OF_YEAR = 366;
	private static final long MILISECOND_COUNT_OF_DAY = 1000L * 60L * 60L * 24L;
	
	private final SimpleDateFormat csvDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	private final SimpleDateFormat tableDateFormat = new SimpleDateFormat("MMM d");
	
	private TableRowSorter<DefaultTableModel> tableRowSorter;
	private FixedColumnTable fixedColumnTable = null;
	
	DefaultTableModel tableModel;
	String filterItem="";

	
	
	private javax.swing.JTable jTableMain;
	private javax.swing.JScrollPane jScrollPane1;
	private LoginPanel topPanel;
	private JPanel tablePanel;
	private RowFilter<Object, Object> filter;

	
	public MainFrame() {
		setTitle("IIR Outages");
		initComponents();
	}
	@SuppressWarnings("unchecked")
	private void initComponents() {
		
		topPanel = new LoginPanel();
		tablePanel = new JPanel();

		
		jScrollPane1 = new javax.swing.JScrollPane();
		
		tablePanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

			
		add(topPanel,BorderLayout.NORTH);
		
		// Begin time
					GregorianCalendar gregorianCalendar = new GregorianCalendar();
					int year = gregorianCalendar.get(Calendar.YEAR);
					int month = gregorianCalendar.get(Calendar.MONTH);
					int dayOfMonth = gregorianCalendar.get(Calendar.DAY_OF_MONTH);

					gregorianCalendar = new GregorianCalendar(year, month, dayOfMonth);
					long nowInMillis = gregorianCalendar.getTimeInMillis();
		
		String[] columnNames = new String[fixedColumnNames.length + DAY_COUNT_OF_YEAR];
		
		for (int i = 0; i < fixedColumnNames.length; i++) {
			columnNames[i] = fixedColumnNames[i];
		}
		
		for (int i = 0; i < DAY_COUNT_OF_YEAR; i++) {
			long dateInMillis = nowInMillis + (MILISECOND_COUNT_OF_DAY * i);
			String dateString = this.tableDateFormat.format(new Date(dateInMillis));
			columnNames[fixedColumnNames.length + i] = dateString;
		}
		
		
		tableModel = new DefaultTableModel(columnNames, 0) {
			/**
			 * 
			 */
			private static final long serialVersionUID = 9106163515371901050L;

			/**
			 * 
			 */

			@Override
			public Class<?> getColumnClass(int columnIndex) {
				if ((columnIndex == 2) || (columnIndex >= fixedColumnNames.length)) {
					return Integer.class;
				} else {
					return String.class;
				}
			}
		};
		
		
		
		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(
				tableModel);

		filter = new RowFilter<Object, Object>() {
			public boolean include(@SuppressWarnings("rawtypes") Entry entry) {
				String name = (String) entry.getValue(3);
				return (name.contains(topPanel.getFilterComboBox().getSelectedItem().toString()));
			}
		};
		
		
		//DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
		
		jTableMain = new JTable(tableModel);
		jTableMain.setAutoResizeMode( JTable.AUTO_RESIZE_OFF );
		
		for (int i = 0; i < DAY_COUNT_OF_YEAR; i++) {
			this.jTableMain.getColumnModel().getColumn(fixedColumnNames.length + i).setPreferredWidth(60);
		}
		
		for (int i = 0; i < fixedColumnNames.length; i++) {
			this.jTableMain.getColumnModel().getColumn(i).setPreferredWidth(150);
		}
		
		
		tableRowSorter = new TableRowSorter<DefaultTableModel>(tableModel);
		//fixedColumnTable.getFixedTable().setRowSorter(this.tableRowSorter);
		jTableMain.setRowSorter(tableRowSorter);
		
		
		//fixedColumnTable = new FixedColumnTable(fixedColumnNames.length, this.jScrollPane1);
			
		
		jScrollPane1.setViewportView(jTableMain);
		
		tablePanel.setLayout(new BorderLayout());
		tablePanel.add(jScrollPane1,BorderLayout.CENTER);
		
		
		if ((this.fixedColumnTable == null) && (this.jTableMain.getColumnCount() >= fixedColumnNames.length)) {
			for (int i = 0; i < fixedColumnNames.length; i++) {
				this.jTableMain.getColumnModel().getColumn(i).setPreferredWidth(90);
			}

			for (int i = 0; i < DAY_COUNT_OF_YEAR; i++) {
					this.jTableMain.getColumnModel().getColumn(fixedColumnNames.length + i).setPreferredWidth(60);
			}
			
			this.fixedColumnTable = new FixedColumnTable(fixedColumnNames.length, this.jScrollPane1);

			// Begin set sorter
			this.tableRowSorter = new TableRowSorter<DefaultTableModel>(tableModel);
			this.fixedColumnTable.getFixedTable().setRowSorter(this.tableRowSorter);
			this.jTableMain.setRowSorter(this.tableRowSorter);
			// End set sorter
		}
		
		

		((DefaultRowSorter<TableModel, Integer>) sorter).setRowFilter(filter);
		
		topPanel.getFilterComboBox().addItemListener(new ItemListener(){
	    	@Override public void itemStateChanged(ItemEvent e) {
	    		System.out.println("test");
	    		 filterItem = (String)e.getItem();
	    		
	    		filter = new RowFilter<Object, Object>() {
	    			public boolean include(@SuppressWarnings("rawtypes") Entry entry) {
	    				String name = (String) entry.getValue(3);
	    				return (name.contains(filterItem));
	    			}
	    		};
	    		
	    		tableRowSorter.setRowFilter(filter);
	    		
	    	}
	    });
		
		
		add(jScrollPane1,BorderLayout.CENTER);	
			
		
	}
	public void refreshTable(CsvReader csvReader) {
		
		if (tableModel.getRowCount() > 0) {
		    for (int i = tableModel.getRowCount() - 1; i > -1; i--) {
		    	tableModel.removeRow(i);
		    }
		}
		
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		int year = gregorianCalendar.get(Calendar.YEAR);
		int month = gregorianCalendar.get(Calendar.MONTH);
		int dayOfMonth = gregorianCalendar.get(Calendar.DAY_OF_MONTH);

		gregorianCalendar = new GregorianCalendar(year, month, dayOfMonth);
		long nowInMillis = gregorianCalendar.getTimeInMillis();
		
		try {
			csvReader.readHeaders();

			while (csvReader.readRecord()) {
				String unitName = csvReader.get(CSV_COLUMN_NAME_UNIT_NAME);
				String outputCapacity = csvReader.get(CSV_COLUMN_NAME_OUTPUT_CAPACITY);
				int numOutputCapacity = -1;
				try {
					numOutputCapacity = (int) Float.parseFloat(outputCapacity);
				} catch (NumberFormatException e) {
					// Do nothing
				}
				String primaryFuel = csvReader.get(CSV_COLUMN_NAME_PRIMARY_FUEL);

				String strStartDate = csvReader.get(CSV_COLUMN_NAME_START_DATE);
				String strEndDate = csvReader.get(CSV_COLUMN_NAME_END_DATE);
				String strCapOffline = csvReader.get(CSV_COLUMN_NAME_CAP_OFFLINE);
				int numCapOffline = -1;
				try {
					numCapOffline = (int) Float.parseFloat(strCapOffline);
				} catch (NumberFormatException e) {
					// Do nothing
					System.out.println("hehe");
				}
				String iso = csvReader.get(CSV_COLUMN_NAME_ISO);

				Object[] rowData = new Object[fixedColumnNames.length + DAY_COUNT_OF_YEAR];
				rowData[0] = unitName;

				if (numOutputCapacity >= 1) {
					rowData[2] = numOutputCapacity;
				}
				rowData[1] = primaryFuel;
				rowData[3] = iso;

				try {
					long startDateInMillis = this.csvDateFormat.parse(strStartDate).getTime();
					long endDateInMillis = this.csvDateFormat.parse(strEndDate).getTime();

					if (numCapOffline >= 0) {
						for (int i = 0; i < DAY_COUNT_OF_YEAR; i++) {
							long dateInMillis = nowInMillis + (MILISECOND_COUNT_OF_DAY * i);

							if ((dateInMillis >= startDateInMillis) && (dateInMillis <= endDateInMillis)) {
								rowData[fixedColumnNames.length + i] = numCapOffline;
							}
						}
					}
				} catch (Exception e) {
					// Do nothing
				}

				tableModel.addRow(rowData);
				jTableMain.setModel(tableModel);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getUsername() {
		return topPanel.getUserField().getText();
	}
	@SuppressWarnings("deprecation")
	public String getPassword() {
		return topPanel.getPassField().getText();
	}
	public void addButtonActionListener(ActionListener listener) {
		topPanel.getRefreshBtn().addActionListener(listener);
	    
		
	}
	

}
