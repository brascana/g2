import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import com.csvreader.CsvReader;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;


public class Controller {
	
	private static final String CSV_FILE_NAME = "data.csv";
	
	private CsvReader csvReader = null;
	
	private static Downloader iir;
	
	
	public Controller() {
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		 
		// get 2/3 of the height, and 2/3 of the width
		int height = 600;
		int width = screenSize.width * 6/7;
		 
		// set the jframe height and width
		
		
		final MainFrame f = new MainFrame();
		f.setSize(new Dimension(width, height));
		centreWindow(f);
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		
		final SwingWorker<String, Void> myWorker= new SwingWorker<String, Void>() {
		    @Override
		    protected String doInBackground() throws Exception {
		    			
					try {	
						iir.getIIR();
						if(iir.getData().length()>1){
							downloadCsvFile(iir.getData());
							loadCsvFromFile();
							f.refreshTable(csvReader);
						}			
						
					} catch (FailingHttpStatusCodeException | IOException e) {
						e.printStackTrace();
					} finally {
						iir.setVisible(false);
						f.setVisible(true);
					}
					
		    	
		        return null;
		    }
		};
		
		f.addButtonActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				iir = new Downloader();
				iir.setVisible(true);
				f.setVisible(false);
				
				SwingUtilities.invokeLater(new Runnable() {
				    public void run() {

				    	myWorker.execute();
				    	        
				    }
				});

			}

		});
		
		boolean loadCsvFromFileSuccessful = loadCsvFromFile();
		if (loadCsvFromFileSuccessful) {
			f.refreshTable(csvReader);
		} 

	}
	private boolean loadCsvFromFile() {
		try {
			this.csvReader = new CsvReader(CSV_FILE_NAME);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	private boolean downloadCsvFile(String data) {
		BufferedWriter bufferedWriter = null;
		try {
			bufferedWriter = new BufferedWriter(new FileWriter(CSV_FILE_NAME));
			bufferedWriter.write(data);
			return true;
		} catch (Exception e) {
			// Do nothing
		} finally {
			try {
				if (bufferedWriter != null)
					bufferedWriter.close();
			} catch (IOException e) {
				// Do nothing
			}
		}
		return false;
	}
	
	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
	
	public static void main(String[] args) {
		
		try {

			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}

		} catch (Exception e) {

		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			//Runnable worker = null;

			public void run() {
				new Controller();
			}
		});
		
		
	}

}
