import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;


import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.RefreshHandler;
import com.gargoylesoftware.htmlunit.TextPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class Downloader extends javax.swing.JFrame  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 100331945797505333L;
	public static final String USERNAME = "a01ham";
	public static final String PASSWORD = "madison";
	
	private static WebClient client;
	
   
	public void getIIR() throws FailingHttpStatusCodeException, MalformedURLException, IOException {
			
		
		this.jLabel1.setText("Downloading: industrialinfo.com");
		
		
		this.repaint();
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
	    java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
	    
	    client = new WebClient(BrowserVersion.INTERNET_EXPLORER_8);
		
		client.getOptions().setUseInsecureSSL(true);
		client.getOptions().setCssEnabled(false);
		client.setRefreshHandler(new CustomRefreshHandler());
		client.getOptions().setTimeout(10000);
		client.getOptions().setThrowExceptionOnFailingStatusCode(false);
		client.getOptions().setThrowExceptionOnScriptError(false);
		client.getOptions().setRedirectEnabled(true);
		client.getOptions().setJavaScriptEnabled(true);
		
		client.setAjaxController(new NicelyResynchronizingAjaxController());
		client.getCache().clear();
		client.getCookieManager().clearCookies();
		
		System.out.println("Starting...");

		HtmlPage page = null;
		
		try {
			
			jLabel1.setText("Downloading: industrialinfo.com");
			jProgressBar1.setValue(10);		
			
			page = client.getPage("http://www.industrialinfo.com/");
			
			jLabel1.setText("Attempting to login...");
			jProgressBar1.setValue(25);
			page.<HtmlInput> getElementByName("loginuser").setValueAttribute(USERNAME);
			page.<HtmlInput> getElementByName("loginpassword").setValueAttribute(PASSWORD);
			HtmlElement loginButton = page.getFirstByXPath("//input[@value='Login']");
			
			page = loginButton.click();
			client.waitForBackgroundJavaScript(10000);
			
			HtmlElement errorE = page.getFirstByXPath("//font[@color='RED']");
			
			if (errorE != null && errorE.asText().endsWith("You are already logged in somewhere else.")) {
				
				
				jLabel1.setText("Err: logged in somewhere else");
				jProgressBar1.setValue(0);	
				
				// log out
				client.getPage("http://www.industrialinfo.com/logout.jsp");

			}
			else {
				
				jLabel1.setText("Downloading IIR Powercast");
				jProgressBar1.setValue(40);	
				
				page = client.getPage("http://www.industrialinfo.com/powercast/home.jsp?prodDestination=./home&style=powercast");
				client.waitForBackgroundJavaScript(10000);	
				
				jProgressBar1.setValue(60);	
				HtmlPage page1 = client.getPage("http://www.industrialinfo.com/powercast/outageQuery.jsp?style=powercast");
				client.waitForBackgroundJavaScript(10000);
					
				jLabel1.setText("Querying Outages...");
				jProgressBar1.setValue(80);	
				HtmlElement radioBnt = page1.getFirstByXPath("//input[@value='months:0:12:']");
				radioBnt.click();
				page1 = ((HtmlButtonInput) page1.getElementByName("Submit1")).click();
				
				page1 = client.getPage("http://www.industrialinfo.com/powercast/selectExportView.jsp?style=powercast&exportID=");
				jLabel1.setText("Dowloading Outage CSV");
				jProgressBar1.setValue(95);	
				HtmlElement buttonExportAll = page1.getFirstByXPath("//input[@value = 'Export All']");
				page1 = buttonExportAll.click();

				TextPage p = client.getPage("http://www.industrialinfo.com/powercast/exportCSV.jsp?PART2=true&EXPORT_ALL=1");
				jProgressBar1.setValue(100);	

				data = p.getContent();
				
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Loggin out...");
			client.getPage("http://www.industrialinfo.com/logout.jsp");
			System.out.println("Logged out...");
		}
		
		
	}
    public Downloader() {
    	initComponents();

        
    }
    public String getData() {
    	
    	return data;
    }
                     
    private void initComponents() {

    	jLabel1 = new JLabel();
    	jProgressBar1 = new JProgressBar();
    	jPanel1 = new JPanel();

        setTitle("IIR Downloader");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }
	public static class CustomRefreshHandler implements RefreshHandler {

		@Override
		public void handleRefresh(Page page, URL url, int arg2) throws IOException {
			// Do nothing
		}

	}

   
    // Variables declaration - do not modify                     
    private  javax.swing.JPanel jPanel1;
    private  javax.swing.JLabel jLabel1;
    private  javax.swing.JProgressBar jProgressBar1;
    private String data ="";
    // End of variables declaration                   
}