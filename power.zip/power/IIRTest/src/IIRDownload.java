import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.NicelyResynchronizingAjaxController;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.RefreshHandler;
import com.gargoylesoftware.htmlunit.TextPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;


public class IIRDownload {
	
	/*public static final String USERNAME = "a01ham";
	public static final String PASSWORD = "madison";*/
	
	
	private static WebClient client;
	

	public void getIIR(String user, String pass) throws FailingHttpStatusCodeException, MalformedURLException, IOException {
		
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(java.util.logging.Level.OFF);
	    java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
	    
	    client = new WebClient(BrowserVersion.INTERNET_EXPLORER_8);
		
		client.getOptions().setUseInsecureSSL(true);
		client.getOptions().setCssEnabled(false);
		client.setRefreshHandler(new CustomRefreshHandler());
		client.getOptions().setTimeout(10000);
		client.getOptions().setThrowExceptionOnFailingStatusCode(false);
		client.getOptions().setThrowExceptionOnScriptError(false);
		client.getOptions().setRedirectEnabled(true);
		client.getOptions().setJavaScriptEnabled(true);
		
		client.setAjaxController(new NicelyResynchronizingAjaxController());
		client.getCache().clear();
		client.getCookieManager().clearCookies();
		
    
		System.out.println("Starting...");

		HtmlPage page = null;
		
		try {
			
			System.out.println("Get - http://www.industrialinfo.com/");
			page = client.getPage("http://www.industrialinfo.com/");
			System.out.println("Downloaded - http://www.industrialinfo.com/");	
			
			System.out.println("Attempting to login...");
			page.<HtmlInput> getElementByName("loginuser").setValueAttribute(user);
			page.<HtmlInput> getElementByName("loginpassword").setValueAttribute(pass);
			HtmlElement loginButton = page.getFirstByXPath("//input[@value='Login']");
			
			page = loginButton.click();
			client.waitForBackgroundJavaScript(10000);
			
			HtmlElement errorE = page.getFirstByXPath("//font[@color='RED']");
			
			if (errorE != null && errorE.asText().endsWith("You are already logged in somewhere else.")) {
				System.out.println("You are already logged in somewhere else. ");
				
				// log out
				client.getPage("http://www.industrialinfo.com/logout.jsp");

			}
			else {
				
				System.out.println("Attempting to view powercast...");
				
				page = client.getPage("http://www.industrialinfo.com/powercast/home.jsp?prodDestination=./home&style=powercast");
				client.waitForBackgroundJavaScript(10000);	
				
				HtmlPage page1 = client.getPage("http://www.industrialinfo.com/powercast/outageQuery.jsp?style=powercast");
				client.waitForBackgroundJavaScript(10000);
					
				HtmlElement radioBnt = page1.getFirstByXPath("//input[@value='months:0:12:']");
				radioBnt.click();
				page1 = ((HtmlButtonInput) page1.getElementByName("Submit1")).click();
				
				page1 = client.getPage("http://www.industrialinfo.com/powercast/selectExportView.jsp?style=powercast&exportID=");

				HtmlElement buttonExportAll = page1.getFirstByXPath("//input[@value = 'Export All']");
				page1 = buttonExportAll.click();

				TextPage p = client.getPage("http://www.industrialinfo.com/powercast/exportCSV.jsp?PART2=true&EXPORT_ALL=1");

				System.out.println(p.getContent());
				
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Loggin out...");
			client.getPage("http://www.industrialinfo.com/logout.jsp");
			System.out.println("Logged out...");
		}
		
		
	}
	public static class CustomRefreshHandler implements RefreshHandler {

		@Override
		public void handleRefresh(Page page, URL url, int arg2) throws IOException {
			// Do nothing
		}


	}
	
	
}
