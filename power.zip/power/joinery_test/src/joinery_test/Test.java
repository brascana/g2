package joinery_test;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


import joinery.DataFrame;
import joinery.DataFrame.PlotType;

public class Test {
	
	public static void main(String[] args) {
		
		DataFrame<?> df,df2;
					
		try {
			
			df = DataFrame.readCsv(Nyiso.getRtZonalLbmp("20160716"))
					.sortBy("Time Stamp");
		
			df2 = DataFrame.readCsv(Nyiso.getRtLimitsFlowsUrl("20160718"))
					.sortBy("Timestamp");
			
			
			DataFrame<?> pf = df.pivot("Time Stamp","Name","LBMP ($/MWHr)");
			DataFrame<?> p2 = df2.pivot("Timestamp","Interface Name","Flow (MWH)");
						
			
			pf.plot(PlotType.LINE);
	
			System.out.print(pf.toString(300));
						
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
}
