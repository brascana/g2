package joinery_test;

 final class Nyiso {
	
	public static String getRtLimitsFlowsUrl(String dateStr){
		return String.format("http://mis.nyiso.com/public/csv/ExternalLimitsFlows/%sExternalLimitsFlows.csv", dateStr);
	}
	
	public static String getRtZonalLbmp(String dateStr) {
		return String.format("http://mis.nyiso.com/public/csv/realtime/%srealtime_zone.csv", dateStr);
	}
	
	public static String getRtConstraint(String dateStr) {
		return String.format("http://mis.nyiso.com/public/csv/LimitingConstraints/%sLimitingConstraints.csv", dateStr);
	}
		
		
}
