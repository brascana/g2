package com.tradingpost.download;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class NsdqEarnCalDownload {

	public static void main(String[] args) {
		NsdqEarnCalDownload ec = new NsdqEarnCalDownload();
	}

	public NsdqEarnCalDownload() {
		try {

			String ua = 
					"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.122 Safari/534.30";
			
			Document doc = Jsoup
					.connect("http://www.nasdaq.com/earnings/earnings-calendar.aspx?date=2014-Aug-06")
					.userAgent(ua)
					.get();

			Elements dataTable = doc.select("#ECCompaniesTable");

			int cCount = 0;

			for (org.jsoup.nodes.Element row : dataTable.select("tr")) {

				for (org.jsoup.nodes.Element column : row.select("td")) {
					cCount++;

					if (cCount == 2)
						parseSymbol(column.text());
				}
				cCount = 0;
			}
		} catch (Exception e) {
		}

	}
	/* 
	 * 
	 * */
	private String parseSymbol(String text) {
		
		int lCount = text.length() - text.replace("(", "").length();
		
		int count =0;
		boolean capture = false;
		
		String symbol = "";
		
		for (char ch : text.toCharArray()){
			
			if(ch ==')')
				capture = false;
			
			if(capture)
				symbol += ch;
			
			if(ch =='(' )
				count++;
			
			if(ch =='(' && count == lCount)
				capture = true;
	    }
			
		return symbol;
	}
}
