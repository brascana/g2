package com.tradingpost.download.ox;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.tradingpost.instrument.StockQuote;


public class OXOptionChain {
	
	private static final String OX_BASE_QUERY_URL="https://www.optionsxpress.com/OXNetTools/Chains/index.aspx?SessionID=&Range=0&lstMarket=0;ChainType=&Ad";
	private StockQuote quote;
	
	//lstMonths=3/20/2015
	public static void main(String[] args) {
		new OXOptionChain();
		
	}
	public OXOptionChain() {	
				
		getOptionChain("AAPL");
	}
	public String getOptionChain(String symb) {
		
		symb = symb.toUpperCase();
		String symbQuery="&Symbol="+symb;
		
		Document html =null;
		
		try {
			
			html = Jsoup.connect(OX_BASE_QUERY_URL+symbQuery).get();
				
		} catch(Exception e){
			
			System.out.println(e);
			
		}
		
		try {
			
			quote =  parseStockQuote(html);
			parseOptionTable(html);
			
		}catch(ParseException pe){
			
			System.out.println(pe);
			
		}

		return "";
	}
	private List parseExpirationList(Document html) throws ParseException {
		
		DateFormat df = new SimpleDateFormat("M/dd/yyyy");
		List<String> months = new ArrayList<String>();
		Element optMonthElements = html.select("div[id*=expMonths").first();

		
		Pattern p = Pattern.compile("(?:(?:0?[1-9]|1[0-2])\\/(?:0?[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0?[1-9]|1[0-2])-(?:30))|(?:(?:0?[13578]|1[02])-31))\\/(?:19|20)[0-9]{2}"); 
		Matcher m = p.matcher(optMonthElements.html());
		 
		 List<String> matches = new ArrayList<String>();
		 while(m.find()){
		     matches.add(m.group());
		 }
		 
		 for (String s: matches){	
			 
			 Calendar cal = new GregorianCalendar();
			 Date dy = df.parse(s);
			 cal.setTime(dy);
			 
			 if(cal.get(Calendar.WEEK_OF_MONTH) == 3) {
				 
				 months.add(s);	 
			 }
			 
		 }
		 return months;
	}

	private StockQuote parseStockQuote(Document html) throws ParseException {
		
		Element quoteTblEle = html.select("#tblQuotebox").first();
		Elements rows = quoteTblEle.select("tr");
			
		    Element row = rows.get(1);
		    Elements cols = row.select("td");
		    
		    String symbol = cols.get(0).text();
		    double lastTrade = Double.parseDouble(cols.get(1).text());
		    
		    
		    String changeStr = cols.get(2).text();
		    changeStr = changeStr.substring(0, changeStr.length()-1);
		    
		    double change = Double.parseDouble(changeStr);
		
		    double bid = Double.parseDouble(cols.get(3).text());
		    double ask = Double.parseDouble(cols.get(4).text());
		    double high = Double.parseDouble(cols.get(5).text());
		    double low = Double.parseDouble(cols.get(6).text());
		    
		    String volumeStr = cols.get(7).text().replace(",", "");
		    double volume = Double.parseDouble(volumeStr);
		    
		    StockQuote quote = new StockQuote();
		    
		    quote.setSymbol(symbol);
		    quote.setSource("OptionsXpress");
		    quote.setLastTrade(lastTrade);
		    quote.setChange(change);
		    quote.setBid(bid);
		    quote.setAsk(ask);
		    quote.setHigh(high);
		    quote.setLow(low);
		    quote.setVolume(volume);
		    
		    return quote;
	}
	private void parseOptionTable(Document html) throws ParseException {
		Element quoteTblEle = html.select("#tbChain").first();
		Elements rows = quoteTblEle.select("tr");
		
		System.out.println(quoteTblEle.html());
		
	}

}
