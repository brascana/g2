package com.bytecode.opencsv.bean;

import com.bytecode.opencsv.CSVReader;

import java.io.IOException;

public class ColumnPositionMappingStrategy<T> extends HeaderColumnNameMappingStrategy<T> {
    private String[] columnMapping = new String[] {};
    public void captureHeader(CSVReader reader) throws IOException {
        //do nothing, first line is not header
    }
    protected String getColumnName(int col) {
        return (null != columnMapping && col < columnMapping.length) ? columnMapping[col] : null ;
    }
    public String[] getColumnMapping() {
        return columnMapping != null ? columnMapping.clone() : null;
    }
    public void setColumnMapping(String[] columnMapping) {
        this.columnMapping = columnMapping != null ? columnMapping.clone() : null;
    }
}