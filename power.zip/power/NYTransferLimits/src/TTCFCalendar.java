
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.bytecode.opencsv.CSVReader;
import com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;
import com.bytecode.opencsv.bean.CsvToBean;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author Default
 */
public final class TTCFCalendar {
    
    final long DAY_IN_MILLIS = 1000 * 60 * 60 * 24;
    
    private TTCFBean bean[];
    private String[] expPath;
    private String[] dailyColumn;
    private String[][] dailyTable;
    private int maxDays = 365;
    private String dateStr ="";

    public TTCFCalendar() {

        downloadData();
        setDailyColumn();
        setDailyTable();

    }

    public void setDailyColumn() {

        dailyColumn = new String[maxDays + 1];
        Date dt = new Date();


        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");

        dailyColumn[0] = "Path";
        for (int i = 0; i < maxDays; i++) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, i);
            dailyColumn[i + 1] = sdf.format(cal.getTime());
        }
    }

    public void setDailyTable() {

        
        dailyTable = new String[expPath.length][maxDays + 1];

        for (int i = 0; i < expPath.length; i++) {
            for (int j = 0; j < dailyTable[i].length; j++) {
                if (j == 0) {
                    dailyTable[i][j] = expPath[i];
                } else {
                    dailyTable[i][j] = "";
                }

            }
        }

        for (int i = 0; i < bean.length; i++) {

            Calendar c = new GregorianCalendar();
            SimpleDateFormat formatter =
                    new SimpleDateFormat("MM/dd/yyyy");
            try {
                Date dOut = formatter.parse(bean[i].getDateOut());
                Date dIn = formatter.parse(bean[i].getDateIn());

                Date dt = new Date();

                for (int j = 0; j < expPath.length; j++) {
                    if (expPath[j].equals(bean[i].getExportPathName())) {

                        if (!bean[i].getCancel1().contains("CANCELLED")) {

                            int start = 9999;
                            int end = 9999;


                            //number of days between the outage start and today
                            int daysUntilStart =
                                    (int) ((dOut.getTime()
                                    - dt.getTime()) / DAY_IN_MILLIS);

                            //number of days between the outage end and today
                            int daysUntilEnd =
                                    (int) ((dIn.getTime()
                                    - dt.getTime()) / DAY_IN_MILLIS) +1;


                            if (daysUntilStart < maxDays) {
                                // if number of days is negative set start to today
                                if (daysUntilStart <= 0) {
                                    start = 0;
                                } else {
                                    start = daysUntilStart;
                                }
                                if (daysUntilEnd >= maxDays) {
                                    end = maxDays - 1;
                                }

                                end = daysUntilEnd;

                                for (int k = start; k <= end; k++) {
                                    if (dailyTable[j][k + 1].equals("")) {

                                        
                                    } else {dailyTable[j][k + 1] = "" + bean[i].getFwdTTCImpact();

                                        if (isParsableToInt(dailyTable[j][k + 1])
                                                && isParsableToInt(bean[i].getFwdTTCImpact())) {

                                            int impact1 = Integer.parseInt(bean[i].getFwdTTCImpact());
                                            int impact2 = Integer.parseInt(dailyTable[j][k + 1]);

                                            if (impact1 > impact2) {
                                                dailyTable[j][k + 1] = "" + bean[i].getFwdTTCImpact();
                                            }

                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception de) {
            }
        }
        /*for (int i = 0; i < expPath.length; i++) {
            for (int j = 0; j < dailyTable[i].length; j++) {
                System.out.print(dailyTable[i][j] + ",");
            }
            System.out.print("\n");
        }*/
    }

    public String[] getDailyColumn() {
        return dailyColumn;
    }
    public String getSchedules(int row, int c){
        
        SimpleDateFormat s =
                    new SimpleDateFormat("MM/dd/yyyy");
        
        SimpleDateFormat d =
                    new SimpleDateFormat("EEE");
        
        
        String output ="";
        int count =0;
        
        //c = c -1;
        
        for(int i=0;i<bean.length;i++) {
            if(bean[i].getExportPathName().equals(expPath[row])
                    &&!bean[i].getCancel1().contains("CANCELLED")){

                try{
                    
                    Date dOut = s.parse(bean[i].getDateOut());
                    Date dIn = s.parse(bean[i].getDateIn());
                    
                    Calendar cal = Calendar.getInstance();
                    
                    
                    cal.add(Calendar.DATE, c);
                      
                    String dateStr = s.format(cal.getTime());
                    Date dTable = s.parse(dateStr);
   
                    
                    if(dOut.before(dTable) || dOut.equals(dTable)) {
                       if(dIn.after(dTable) || dIn.equals(dTable)) {
                           
                            int lineLength = 105;                          
                            
                            int rtsa = bean[i].getRtsaFacilityName().length();
                            int spacer1 = lineLength - bean[i].getRtsaFacilityName().length();
                            
                            String line2 = ""+d.format(dOut)+ " "+bean[i].getDateOut()+" to "+d.format(dIn)+" "+bean[i].getDateIn();
                            String update ="";
                            if (!bean[i].getCancel1().equals(""))
                                update +="     "+bean[i].getCancel1();
                            if (!bean[i].getModMess().equals(""))
                                update +=" BY "+bean[i].getModMess() +" "+bean[i].getCancel2();
                            
                            int spacer2 = lineLength-(line2.length()+update.length());
                            
                            String line3 = "  "+bean[i].getTimeOut()+"  "+bean[i].getAti()+"  "+bean[i].getTimeIn();
                            int spacer6 = 72-line3.length();
                            line3+=getBlanks(spacer6)+bean[i].getExportPathName();
                            int spacer7 = 98-line3.length();
                       
                            
                            String workSch = "Work Scheduled by: "+bean[i].getCalledIn();
                            int spacer3= 64 - workSch.length();
      
                            int spacer4 = 5-bean[i].getFwdTTCImpact().length();
                            int spacer5 = 9-bean[i].getFwdTTCAllIn().length();
                            int spacer8 = 4-bean[i].getFwdTTC().length();
                            String line4 ="                                                                TTC With All Lines In Service";
                                    

                            count++;
                         if(count == 1)
                            output +="---------------------------------------------------------------------------------------------------------\n";
                         
                            output+=bean[i].getRtsaFacilityName()+getBlanks(spacer1-5)+"FWD\n";
                            output+=line2+update+getBlanks(spacer2-8)+"(Import)\n";
                            output+=line3+getBlanks(spacer7)+getBlanks(spacer8)+bean[i].getFwdTTC()+" MW \n";
                            output+=workSch+getBlanks(spacer3)+"Impacts Total Transfer Capability"+getBlanks(spacer4)+bean[i].getFwdTTCImpact()+" MW \n";
                            output+=line4+=getBlanks(spacer5)+bean[i].getFwdTTCAllIn()+" MW \n";
                            output +="---------------------------------------------------------------------------------------------------------\n";
                    
                         }
                       }
                    
                }catch (Exception de){}
                
                
            }
        }
        return output;
    }

    public String[][] getDailyTable() {
        return dailyTable;
    }
    
    public String getBlanks(int num){
        String blanks="";
        for(int i=0;i<num;i++){
            blanks +=" ";
        }
        return blanks;
    }

    public void downloadData() {   
                
        try {
            
            String dy = new SimpleDateFormat("yyyyMMdd").format(new Date());
            dateStr = dy;
            String urlStr = "http://mis.nyiso.com/public/csv/ttcf/"+dy+"ttcf.csv";
            URL u = new URL(urlStr); 
            HttpURLConnection huc = (HttpURLConnection)u.openConnection(); 
            huc.setDoOutput(true);
            huc.setRequestMethod("GET"); 
            huc.connect() ; 
            
            OutputStream os = huc.getOutputStream(); 
            int code = huc.getResponseCode(); 
            
            if(code == 404) {
                DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DATE, -1);    
                dy = dateFormat.format(cal.getTime());
                dateStr = dy;
                urlStr = "http://mis.nyiso.com/public/csv/ttcf/"+dy+"ttcf.csv";
            }
            
                        
            System.out.print(code);
            
            
            //http://mis.nyiso.com/public/csv/ttcf/20141205ttcf.csv
            
            
            URL url = new URL(urlStr);
            url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

            ColumnPositionMappingStrategy<TTCFBean> strat = new ColumnPositionMappingStrategy<TTCFBean>();
            strat.setType(TTCFBean.class);

            CSVReader reader =
                    new CSVReader(in);

            String[] columns = new String[]{"rtsaFacilityName",
                "dateOut", "timeOut", "dateIn", "timeIn", "ati",
                "calledIn", "cancel1", "modMess", "cancel2", "pathName",
                "exportPathName", "fwdTTC", "fwdTTCImpact", "fwdTTCAllIn",
                "revTTC", "revTTCImpact", "revTTCAllIn", "ptid", "aar"};


            strat.setColumnMapping(columns);
            CsvToBean<TTCFBean> csv = new CsvToBean();

            List<TTCFBean> list = csv.parse(strat, reader);

            bean = new TTCFBean[list.size() - 1];

            String path[] = new String[bean.length];

            for (int i = 1; i <= bean.length; i++) {
                bean[i - 1] = (TTCFBean) list.get(i);
                path[i - 1] = bean[i - 1].getExportPathName();
            }

            Set<String> uniqueExpPaths =
                    new java.util.HashSet<String>(java.util.Arrays.asList(path));

            expPath = uniqueExpPaths.toArray(new String[0]);

        } catch (Exception e2) {
            System.out.println(e2);
        }
    }

    public boolean isParsableToInt(String i) {
        try {
            Integer.parseInt(i);
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }
    public String getDateStr() {
        return dateStr;
    }
}