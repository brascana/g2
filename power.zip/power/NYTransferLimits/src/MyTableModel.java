import javax.swing.table.DefaultTableModel;


public class MyTableModel extends DefaultTableModel {

   /**
	 * 
	 */
	private static final long serialVersionUID = -7501280622015004306L;

public MyTableModel(Object[][] tableData, Object[] colNames) {
      super(tableData, colNames);
   }

   public boolean isCellEditable(int row, int column) {
      return false;
   }
}
