
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;



public class NYTransferLimits {	
	
	public NYTransferLimits() {
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		 
		// get 2/3 of the height, and 2/3 of the width
		int height = 600;
		int width = screenSize.width * 6/7;
		 
		// set the jframe height and width
		
		
		final MainForm f = new MainForm();
		f.setSize(new Dimension(width, height));
		centreWindow(f);
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
		
		/*
		final SwingWorker<String, Void> myWorker= new SwingWorker<String, Void>() {
		    @Override
		    protected String doInBackground() throws Exception {
		    		
					try {	
						iir.getIIR();
						if(iir.getData().length()>1){
							downloadCsvFile(iir.getData());
							loadCsvFromFile();
							f.refreshTable(csvReader);
						}			
						
					} catch (FailingHttpStatusCodeException | IOException e) {
						e.printStackTrace();
					} finally {
						iir.setVisible(false);
						f.setVisible(true);
					}
					
		    	
		        return null;
		    }
		};
		*/
		


	}

	
	public static void centreWindow(Window frame) {
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - frame.getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - frame.getHeight()) / 2);
	    frame.setLocation(x, y);
	}
	
	public static void main(String[] args) {
		
		try {

			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}

		} catch (Exception e) {

		}
		java.awt.EventQueue.invokeLater(new Runnable() {
			//Runnable worker = null;

			public void run() {
				new NYTransferLimits();
			}
		});
		
		
	}

}