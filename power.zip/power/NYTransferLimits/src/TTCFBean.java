import java.beans.*;
import java.io.Serializable;

/**
 *
 * @author Laptop
 */
public class TTCFBean implements Serializable {
    
        
    /**
	 * 
	 */
	private static final long serialVersionUID = -3335419172658072510L;

	private PropertyChangeSupport propertySupport;
    
    private String rtsaFacilityName;
    private String dateOut;
    private String timeOut;
    private String dateIn;
    private String timeIn;
    private String ati;
    private String calledIn;
    private String cancel1;     
    private String modMess;
    private String cancel2;
    private String pathName;
    private String exportPathName;
    private String fwdTTC;
    private String fwdTTCImpact;
    private String fwdTTCAllIn;
    private String revTTC;
    private String revTTCImpact;
    private String revTTCAllIn;
    private String ptid;
    private String aar;
    
    
    
    public TTCFBean() {
        propertySupport = new PropertyChangeSupport(this);
    }
    
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }

    /**
     * @return the rtsaFacilityName
     */
    public String getRtsaFacilityName() {
        return rtsaFacilityName;
    }

    /**
     * @param rtsaFacilityName the rtsaFacilityName to set
     */
    public void setRtsaFacilityName(String rtsaFacilityName) {
        this.rtsaFacilityName = rtsaFacilityName;
    }

    /**
     * @return the dateOut
     */
    public String getDateOut() {
        return dateOut;
    }

    /**
     * @param dateOut the dateOut to set
     */
    public void setDateOut(String dateOut) {
        this.dateOut = dateOut;
    }

    /**
     * @return the timeOut
     */
    public String getTimeOut() {
        return timeOut;
    }

    /**
     * @param timeOut the timeOut to set
     */
    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    /**
     * @return the dateIn
     */
    public String getDateIn() {
        return dateIn;
    }

    /**
     * @param dateIn the dateIn to set
     */
    public void setDateIn(String dateIn) {
        this.dateIn = dateIn;
    }

    /**
     * @return the timeIn
     */
    public String getTimeIn() {
        return timeIn;
    }

    /**
     * @param timeIn the timeIn to set
     */
    public void setTimeIn(String timeIn) {
        this.timeIn = timeIn;
    }

    /**
     * @return the ati
     */
    public String getAti() {
        return ati;
    }

    /**
     * @param ati the ati to set
     */
    public void setAti(String ati) {
        this.ati = ati;
    }

    /**
     * @return the calledIn
     */
    public String getCalledIn() {
        return calledIn;
    }

    /**
     * @param calledIn the calledIn to set
     */
    public void setCalledIn(String calledIn) {
        this.calledIn = calledIn;
    }

    /**
     * @return the cancel1
     */
    public String getCancel1() {
        return cancel1;
    }

    /**
     * @param cancel1 the cancel1 to set
     */
    public void setCancel1(String cancel1) {
        this.cancel1 = cancel1;
    }

    /**
     * @return the pathName
     */
    public String getPathName() {
        return pathName;
    }

    /**
     * @param pathName the pathName to set
     */
    public void setPathName(String pathName) {
        this.pathName = pathName;
    }

    /**
     * @return the exportPathName
     */
    public String getExportPathName() {
        return exportPathName;
    }

    /**
     * @param exportPathName the exportPathName to set
     */
    public void setExportPathName(String exportPathName) {
        this.exportPathName = exportPathName;
    }

    /**
     * @return the fwdTTC
     */
    public String getFwdTTC() {
        return fwdTTC;
    }

    /**
     * @param fwdTTC the fwdTTC to set
     */
    public void setFwdTTC(String fwdTTC) {
        this.fwdTTC = fwdTTC;
    }

    /**
     * @return the fwdTTCImpact
     */
    public String getFwdTTCImpact() {
        return fwdTTCImpact;
    }

    /**
     * @param fwdTTCImpact the fwdTTCImpact to set
     */
    public void setFwdTTCImpact(String fwdTTCImpact) {
        this.fwdTTCImpact = fwdTTCImpact;
    }

    /**
     * @return the fwdTTCAllIn
     */
    public String getFwdTTCAllIn() {
        return fwdTTCAllIn;
    }

    /**
     * @param fwdTTCAllIn the fwdTTCAllIn to set
     */
    public void setFwdTTCAllIn(String fwdTTCAllIn) {
        this.fwdTTCAllIn = fwdTTCAllIn;
    }

    /**
     * @return the revTTC
     */
    public String getRevTTC() {
        return revTTC;
    }

    /**
     * @param revTTC the revTTC to set
     */
    public void setRevTTC(String revTTC) {
        this.revTTC = revTTC;
    }

    /**
     * @return the revTTCImpact
     */
    public String getRevTTCImpact() {
        return revTTCImpact;
    }

    /**
     * @param revTTCImpact the revTTCImpact to set
     */
    public void setRevTTCImpact(String revTTCImpact) {
        this.revTTCImpact = revTTCImpact;
    }

    /**
     * @return the revTTCAllIn
     */
    public String getRevTTCAllIn() {
        return revTTCAllIn;
    }

    /**
     * @param revTTCAllIn the revTTCAllIn to set
     */
    public void setRevTTCAllIn(String revTTCAllIn) {
        this.revTTCAllIn = revTTCAllIn;
    }

    /**
     * @return the ptid
     */
    public String getPtid() {
        return ptid;
    }

    /**
     * @param ptid the ptid to set
     */
    public void setPtid(String ptid) {
        this.ptid = ptid;
    }

    /**
     * @return the aar
     */
    public String getAar() {
        return aar;
    }

    /**
     * @param aar the aar to set
     */
    public void setAar(String aar) {
        this.aar = aar;
    }

    /**
     * @return the modMess
     */
    public String getModMess() {
        return modMess;
    }

    /**
     * @param modMess the modMess to set
     */
    public void setModMess(String modMess) {
        this.modMess = modMess;
    }

    /**
     * @return the cancel2
     */
    public String getCancel2() {
        return cancel2;
    }

    /**
     * @param cancel2 the cancel2 to set
     */
    public void setCancel2(String cancel2) {
        this.cancel2 = cancel2;
    }
}
