package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.ancillary.NyisoHourlyAncillary;
import com.powerlib.util.HttpFileDownload;

public class NyisoDamAncillaryQuery {
	
	private CsvReader csvReader = null;
    private HttpFileDownload downloader;
    private String urlPath;
	
    private HashMap  <String,NyisoHourlyAncillary>se10SMap;
	private HashMap  <String,NyisoHourlyAncillary>se10NSMap;
	private HashMap  <String,NyisoHourlyAncillary>se30ORMap;
	
	private HashMap  <String,NyisoHourlyAncillary>e10SMap;
	private HashMap  <String,NyisoHourlyAncillary>e10NSMap;
	private HashMap  <String,NyisoHourlyAncillary>e30ORMap;
	private HashMap  <String,NyisoHourlyAncillary>eRegMap;
	private HashMap  <String,NyisoHourlyAncillary>w10SMap;
	private HashMap  <String,NyisoHourlyAncillary>w10NSMap;
	private HashMap  <String,NyisoHourlyAncillary>w30ORMap;
	private HashMap  <String,NyisoHourlyAncillary>wRegMap;
	
	
	private String se10S_ID = "SENY 10 Min Spin";
	private String se10NS_ID = "SENY 10 Min Non Spin";
	private String se30OR_ID = "SENY 30 Min OR";
	
	private String e10S_ID = "East 10 Min Spin";
	private String e10NS_ID = "East 10 Min Non Spin";
	private String e30OR_ID = "East 30 Min OR";
	private String eReg_ID = "East Reg";
	private String w10S_ID = "West 10 Min Spin";
	private String w10NS_ID = "West 10 Min Non Spin";
	private String w30OR_ID = "West 30 Min OR";
	private String wReg_ID = "West Reg";
		
	public NyisoDamAncillaryQuery(String path) {
		
		urlPath = path;
        downloader = new HttpFileDownload();
        
        se10SMap = new HashMap<String, NyisoHourlyAncillary>();
        se10NSMap = new HashMap<String, NyisoHourlyAncillary>();
        se30ORMap = new HashMap<String, NyisoHourlyAncillary>();
        e10SMap = new HashMap<String, NyisoHourlyAncillary>();
        e10NSMap = new HashMap<String, NyisoHourlyAncillary>();
        e30ORMap = new HashMap<String, NyisoHourlyAncillary>();
        eRegMap = new HashMap<String, NyisoHourlyAncillary>();
        w10SMap = new HashMap<String, NyisoHourlyAncillary>();
        w10NSMap = new HashMap<String, NyisoHourlyAncillary>();
        w30ORMap = new HashMap<String, NyisoHourlyAncillary>();
        wRegMap = new HashMap<String, NyisoHourlyAncillary>();

	}
	
	public boolean query() {
		
		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);

					double se10S = Double.parseDouble(csvReader.get(2));
					double se10NS = Double.parseDouble(csvReader.get(3));
					double se30OR = Double.parseDouble(csvReader.get(4));			
					double e10S = Double.parseDouble(csvReader.get(5));
					double e10NS = Double.parseDouble(csvReader.get(6));
					double e30OR = Double.parseDouble(csvReader.get(7));
					double eReg = Double.parseDouble(csvReader.get(8));
					double w10S = Double.parseDouble(csvReader.get(9));
					double w10NS = Double.parseDouble(csvReader.get(10));
					double w30OR = Double.parseDouble(csvReader.get(11));
					double wReg = Double.parseDouble(csvReader.get(12));

					DateTime dt = nyTimestampToDateTime(timestamp);

					NyisoHourlyAncillary ancillarySE10S;
					NyisoHourlyAncillary ancillarySE10NS;
					NyisoHourlyAncillary ancillarySE30OR;
					NyisoHourlyAncillary ancillaryE10S;
					NyisoHourlyAncillary ancillaryE10NS;
					NyisoHourlyAncillary ancillaryE30OR;
					NyisoHourlyAncillary ancillaryEReg;
					NyisoHourlyAncillary ancillaryW10S;
					NyisoHourlyAncillary ancillaryW10NS;
					NyisoHourlyAncillary ancillaryW30OR;
					NyisoHourlyAncillary ancillaryWReg;

					
					// ----------------------------- Set SENY 10 Spin ----------------------------
					
					
					if (se10SMap.containsKey(se10S_ID)) {
						ancillarySE10S = (NyisoHourlyAncillary) se10SMap.get(se10S_ID);
					} else {
						ancillarySE10S = new NyisoHourlyAncillary();
						ancillarySE10S.setProduct(se10S_ID);
					}

					ancillarySE10S.setPrice(dt, se10S);

					se10SMap.put(se10S_ID, ancillarySE10S);
					
					
					// ----------------------------- Set SENY 10 Min Non Spin -----------------------
					
					if (se10NSMap.containsKey(se10NS_ID)) {
						ancillarySE10NS = (NyisoHourlyAncillary) se10NSMap.get(se10NS_ID);
					} else {
						ancillarySE10NS = new NyisoHourlyAncillary();
						ancillarySE10NS.setProduct(se10NS_ID);
					}

					ancillarySE10NS.setPrice(dt, se10NS);

					se10NSMap.put(se10NS_ID, ancillarySE10NS);
					
					
					
					
					// ----------------------------- Set SENY 30 Min OR -----------------------
					
					if (se30ORMap.containsKey(se30OR_ID)) {
						ancillarySE30OR = (NyisoHourlyAncillary) se30ORMap.get(se30OR_ID);
					} else {
						ancillarySE30OR = new NyisoHourlyAncillary();
						ancillarySE30OR.setProduct(se30OR_ID);
					}

					ancillarySE30OR.setPrice(dt, se30OR);

					se30ORMap.put(se30OR_ID, ancillarySE30OR);
										
					
					// ----------------------------- Set East 10 Spin ----------------------------
					
					
					if (e10SMap.containsKey(e10S_ID)) {
						ancillaryE10S = (NyisoHourlyAncillary) e10SMap.get(e10S_ID);
					} else {
						ancillaryE10S = new NyisoHourlyAncillary();
						ancillaryE10S.setProduct(e10S_ID);
					}

					ancillaryE10S.setPrice(dt, e10S);

					e10SMap.put(e10S_ID, ancillaryE10S);
					
					
					// ----------------------------- Set East 10 Min Non Spin -----------------------
					
					if (e10NSMap.containsKey(e10NS_ID)) {
						ancillaryE10NS = (NyisoHourlyAncillary) e10NSMap.get(e10NS_ID);
					} else {
						ancillaryE10NS = new NyisoHourlyAncillary();
						ancillaryE10NS.setProduct(e10NS_ID);
					}

					ancillaryE10NS.setPrice(dt, e10NS);

					e10NSMap.put(e10NS_ID, ancillaryE10NS);
					
					
					// ----------------------------- Set East 30 Min OR -----------------------
					
					if (e30ORMap.containsKey(e30OR_ID)) {
						ancillaryE30OR = (NyisoHourlyAncillary) e30ORMap.get(e30OR_ID);
					} else {
						ancillaryE30OR = new NyisoHourlyAncillary();
						ancillaryE30OR.setProduct(e30OR_ID);
					}

					ancillaryE30OR.setPrice(dt, e30OR);

					e30ORMap.put(e30OR_ID, ancillaryE30OR);
					
					
					// ----------------------------- Set East Reg ---------------------------
					
					if (eRegMap.containsKey(eReg_ID)) {
						ancillaryEReg = (NyisoHourlyAncillary) eRegMap.get(eReg_ID);
					} else {
						ancillaryEReg = new NyisoHourlyAncillary();
						ancillaryEReg.setProduct(eReg_ID);
					}

					ancillaryEReg.setPrice(dt, eReg);

					eRegMap.put(eReg_ID, ancillaryEReg);
					
					

					// ----------------------------- Set West 10 Spin ----------------------------
					
					
					if (w10SMap.containsKey(w10S_ID)) {
						ancillaryW10S = (NyisoHourlyAncillary) w10SMap.get(w10S_ID);
					} else {
						ancillaryW10S = new NyisoHourlyAncillary();
						ancillaryW10S.setProduct(w10S_ID);
					}

					ancillaryW10S.setPrice(dt, w10S);

					w10SMap.put(w10S_ID, ancillaryW10S);
					
					
					// ----------------------------- Set West 10 Min Non Spin -----------------------
					
					if (w10NSMap.containsKey(w10NS_ID)) {
						ancillaryW10NS = (NyisoHourlyAncillary) w10NSMap.get(w10NS_ID);
					} else {
						ancillaryW10NS = new NyisoHourlyAncillary();
						ancillaryW10NS.setProduct(w10NS_ID);
					}

					ancillaryW10NS.setPrice(dt, w10NS);

					w10NSMap.put(w10NS_ID, ancillaryW10NS);
					
					
					// ----------------------------- Set West 30 Min OR -----------------------
					
					if (w30ORMap.containsKey(w30OR_ID)) {
						ancillaryW30OR = (NyisoHourlyAncillary) w30ORMap.get(w30OR_ID);
					} else {
						ancillaryW30OR = new NyisoHourlyAncillary();
						ancillaryW30OR.setProduct(w30OR_ID);
					}

					ancillaryW30OR.setPrice(dt, w30OR);

					w30ORMap.put(w30OR_ID, ancillaryW30OR);
					
					
					// ----------------------------- Set West Reg ---------------------------
					
					if (wRegMap.containsKey(wReg_ID)) {
						ancillaryWReg = (NyisoHourlyAncillary) wRegMap.get(wReg_ID);
					} else {
						ancillaryWReg = new NyisoHourlyAncillary();
						ancillaryWReg.setProduct(wReg_ID);
					}http://marketplace.eclipse.org/marketplace-client-intro?mpc_install=1403812

					ancillaryWReg.setPrice(dt, wReg);

					wRegMap.put(wReg_ID, ancillaryWReg);
						
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
			
		}
		return true;
	}
	
	private DateTime nyTimestampToDateTime(String time) {
		
		DateTimeFormatter dtf 
			= DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
		
		DateTime dt = dtf.parseDateTime(time);
		return(dt);
	}
	public void setData(){
		
	}
	
	public HashMap <String, NyisoHourlyAncillary> getSE10SMap() {
		return se10SMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getSE10NSMap() {
		return se10NSMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getSE30ORMap() {
		return se30ORMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getE10SMap() {
		return e10SMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getE10NSMap() {
		return e10NSMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getE30ORMap() {
		return e30ORMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getERegMap() {
		return eRegMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getW10SMap() {
		return w10SMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getW10NSMap() {
		return w10NSMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getW30ORMap() {
		return w30ORMap;
	}
	public HashMap <String, NyisoHourlyAncillary> getWRegMap() {
		return wRegMap;
	}


}
