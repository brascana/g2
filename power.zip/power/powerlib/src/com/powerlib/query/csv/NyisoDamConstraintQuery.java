package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoHourlyConstraint;
import com.powerlib.util.HttpFileDownload;

public class NyisoDamConstraintQuery {

	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;

	private HashMap<String, NyisoHourlyConstraint> constraintMap;

	public NyisoDamConstraintQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		constraintMap = new HashMap<String, NyisoHourlyConstraint>();

	}

	public boolean query() {

		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		} else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					//String timeZone = csvReader.get(1);
					String limitingFacility = csvReader.get(2);
					String ptid = csvReader.get(3);
					String contingency = csvReader.get(4);

					double cost = Double.parseDouble(csvReader.get(5));

					DateTime dt = nyTimestampToDateTime(timestamp);

					NyisoHourlyConstraint constraint;

					if (constraintMap.containsKey(ptid)) {
						constraint = (NyisoHourlyConstraint) constraintMap
								.get(ptid);
					} else {
						constraint = new NyisoHourlyConstraint();
						constraint.setLimitingFacility(limitingFacility);
						constraint.setPtid(ptid);
						constraint.setContingency(contingency);

					}
					constraint.setCost(dt, cost);
					constraintMap.put(ptid, constraint);

				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}

	private DateTime nyTimestampToDateTime(String time) {

		DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");

		DateTime dt = dtf.parseDateTime(time);
		return (dt);
	}
	public HashMap <String, NyisoHourlyConstraint> getConstraintMap() {
		return constraintMap;
	}
}