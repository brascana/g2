package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoTtcf;
import com.powerlib.util.HttpFileDownload;

public class NyisoTtcfQuery {

	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;

	private HashMap<Integer, NyisoTtcf> ttcfMap;

	public NyisoTtcfQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		ttcfMap = new HashMap<Integer, NyisoTtcf>();

	}

	public boolean query() {

		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		} else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				int recordCount = 0;
				while (csvReader.readRecord()) {

					recordCount++;

					String facilityName = csvReader.get(0);
					String dateOut = csvReader.get(1);
					String timeOut = csvReader.get(2);
					String dateIn = csvReader.get(3);
					String timeIn = csvReader.get(4);
					String ati = csvReader.get(5);
					String calledIn = csvReader.get(6);
					String cancel1 = csvReader.get(7);
					String modMes = csvReader.get(8);
					String cancel2 = csvReader.get(9);
					String pathName = csvReader.get(10);
					String exportPathName = csvReader.get(11);
					String fwdTtcCap = csvReader.get(12);
					String fwdTtcImpact = csvReader.get(13);
					String fwdTtcInService = csvReader.get(14);
					String revTtcCap = csvReader.get(15);
					String revTtcImpact = csvReader.get(16);
					String revTtcInService = csvReader.get(17);
					String ptid = csvReader.get(18);
					String arr = csvReader.get(19);

					NyisoTtcf ttcf;

					if (ttcfMap.containsKey(recordCount)) {
						ttcf = (NyisoTtcf) ttcfMap.get(recordCount);
					} else {
						ttcf = new NyisoTtcf();
					}

					ttcf.setRecordId(recordCount);
					ttcf.setFacilityName(facilityName);
					ttcf.setAti(ati);
					ttcf.setCalledIn(calledIn);
					ttcf.setCancel1(cancel1);
					ttcf.setModMes(modMes);
					ttcf.setCancel2(cancel2);
					ttcf.setPathName(pathName);
					ttcf.setExportPathName(exportPathName);
					ttcf.setPtid(ptid);
					ttcf.setArr(arr);

					if (nyTimestampToDateTime(dateOut, timeOut) != null)
						ttcf.setDateOut(nyTimestampToDateTime(dateOut, timeOut));

					if (nyTimestampToDateTime(dateIn, timeIn) != null)
						ttcf.setDateIn(nyTimestampToDateTime(dateIn, timeIn));

					if (isNumeric(fwdTtcCap))
						ttcf.setFwdTtcCap(Integer.parseInt(fwdTtcCap));

					if (isNumeric(fwdTtcImpact))
						ttcf.setFwdTtcImpact(Integer.parseInt(fwdTtcImpact));

					if (isNumeric(fwdTtcInService))
						ttcf.setFwdTtcInService(Integer
								.parseInt(fwdTtcInService));

					if (isNumeric(revTtcCap))
						ttcf.setRevTtcCap(Integer.parseInt(revTtcCap));

					if (isNumeric(revTtcImpact))
						ttcf.setRevTtcImpact(Integer.parseInt(revTtcImpact));

					if (isNumeric(revTtcInService))
						ttcf.setRevTtcInService(Integer
								.parseInt(revTtcInService));

					ttcfMap.put(recordCount, ttcf);
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}

	private DateTime nyTimestampToDateTime(String dy, String tm) {

		String time = dy + " " + tm;

		try {
			DateTimeFormatter dtf = DateTimeFormat
					.forPattern("MM/dd/yyyy HH:mm");
			DateTime dt = dtf.parseDateTime(time);
			return dt;

		} catch (Exception e) {

		}

		try {
			DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy");
			DateTime dt = dtf.parseDateTime(dy);
			return (dt);

		} catch (Exception e) {

			return null;
		}

	}

	public static boolean isNumeric(String str) {
		try {
			@SuppressWarnings("unused")
			double d = Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

	public HashMap<Integer, NyisoTtcf> getTtcfMap() {
		return ttcfMap;
	}
}