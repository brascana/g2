package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoTermTransOut;
import com.powerlib.util.HttpFileDownload;

public class NyisoTermTransOutQuery {

	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;

	private HashMap<String, NyisoTermTransOut> outageMap;

	public NyisoTermTransOutQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		outageMap = new HashMap<String, NyisoTermTransOut>();

	}

	public boolean query() {

		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		} else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String ptid = csvReader.get(0);
					String outageId = csvReader.get(1);
					String equipmentName = csvReader.get(2);
					String equipmentType = csvReader.get(3);
					String dateOut = csvReader.get(4);
					String timeOut = csvReader.get(5);
					String dateIn = csvReader.get(6);
					String timeIn = csvReader.get(7);
					String calledIn = csvReader.get(8);
					String status = csvReader.get(9);
					String statusDate = csvReader.get(10);
					String arr = csvReader.get(11);

					NyisoTermTransOut outage;

					if (outageMap.containsKey(outageId)) {
						outage = (NyisoTermTransOut) outageMap.get(outageId);
					} else {
						outage = new NyisoTermTransOut();
					}

					outage.setOutageId(outageId);
					outage.setPtid(ptid);
					outage.setEquipmentName(equipmentName);
					outage.setEquipmentType(equipmentType);
					outage.setTimeOut(timeOut);
					outage.setTimeIn(timeIn);
					outage.setCalledIn(calledIn);
					outage.setStatus(status);
					outage.setStatusDate(statusDate);
					outage.setArr(arr);

					if (nyTimestampToDateTime(dateOut, timeOut) != null)
						outage.setDateOut(nyTimestampToDateTime(dateOut,timeOut));

					if (nyTimestampToDateTime(dateIn, timeIn) != null)
						outage.setDateIn(nyTimestampToDateTime(dateIn, timeIn));
					
					
					
					outageMap.put(outageId, outage);
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}

	private DateTime nyTimestampToDateTime(String dy, String tm) {

		String time = dy + " " + tm;
		
		try {
			DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy hh:mm aa");
			DateTime dt = dtf.parseDateTime(time);
			return dt;

		} catch (Exception e) {
			
		}
		
		try {
			DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy");
			DateTime dt = dtf.parseDateTime(dy);
			
			return (dt);

		} catch (Exception e) {
			
			return null;
		}

	}

	public HashMap<String, NyisoTermTransOut> getOutageMap() {
		return outageMap;
	}
}