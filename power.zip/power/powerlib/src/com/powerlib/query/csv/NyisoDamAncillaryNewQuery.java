package com.powerlib.query.csv;

import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.util.HttpFileDownload;

public class NyisoDamAncillaryNewQuery {
	
	private CsvReader csvReader = null;
    private HttpFileDownload downloader;
    private String urlPath;
	
	private HashMap  <String,NyisoHourlyPriceSet> spin10minMap;
	private HashMap  <String,NyisoHourlyPriceSet> nonspin10minMap;
	private HashMap  <String,NyisoHourlyPriceSet> nonspin30minMap;
	private HashMap  <String,NyisoHourlyPriceSet> nycaRegMap;
	
	
	public NyisoDamAncillaryNewQuery() {
		
		spin10minMap = new HashMap<String, NyisoHourlyPriceSet>();
		nonspin10minMap = new HashMap<String, NyisoHourlyPriceSet>();
		nonspin30minMap = new HashMap<String, NyisoHourlyPriceSet>();
		nycaRegMap = new HashMap<String, NyisoHourlyPriceSet>();
	}
	
	public boolean readCSVFile(){
		try {
			
			csvReader = new CsvReader(urlPath);
			parse(csvReader);
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return true;
	}
	
	public void parse(CsvReader csvReader) {
		
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					String name = csvReader.get(2);
					String ptid = csvReader.get(3);

					double s10 = Double.parseDouble(csvReader.get(4));
					double ns10 = Double.parseDouble(csvReader.get(5));
					double ns30 = Double.parseDouble(csvReader.get(6));
					double reg = Double.parseDouble(csvReader.get(7));
					
										
					DateTime dt = nyTimestampToDateTime(timestamp);
										
					DateTime dt2 = dt;
					
					dt2.withZone(DateTimeZone.forID("America/New_York"));
													
					NyisoHourlyPriceSet s10PriceSet;
					NyisoHourlyPriceSet ns10PriceSet;
					NyisoHourlyPriceSet ns30PriceSet;
					NyisoHourlyPriceSet regPriceSet;


					// -------------------------------Set 10 min spin ----------------------------------
					
					if (spin10minMap.containsKey(ptid)) {
						s10PriceSet = (NyisoHourlyPriceSet) spin10minMap.get(ptid);
					} else {
						s10PriceSet = new NyisoHourlyPriceSet();
						s10PriceSet.setName(name);
						s10PriceSet.setPtid(ptid);
					}

					if (s10PriceSet.containsHour(dt2)) {
						dt2 = dt2.plusHours(1);
					}
					s10PriceSet.setPrice(dt2, s10);
					spin10minMap.put(ptid, s10PriceSet);
					
					// -------------------------------Set 10 min non spin ------------------------------
					
					if (nonspin10minMap.containsKey(ptid)) {
						ns10PriceSet = (NyisoHourlyPriceSet) nonspin10minMap.get(ptid);
					} else {
						ns10PriceSet = new NyisoHourlyPriceSet();
					}
					ns10PriceSet.setName(name);
					ns10PriceSet.setPtid(ptid);

					ns10PriceSet.setPrice(dt2, ns10);

					nonspin10minMap.put(ptid, ns10PriceSet);
					
					// -------------------------------Set Loss -----------------------------------
					
					if (nonspin30minMap.containsKey(ptid)) {
						ns30PriceSet = (NyisoHourlyPriceSet) nonspin30minMap.get(ptid);
					} else {
						ns30PriceSet = new NyisoHourlyPriceSet();
					}
					ns30PriceSet.setName(name);
					ns30PriceSet.setPtid(ptid);

					ns30PriceSet.setPrice(dt2, ns30);

					nonspin30minMap.put(ptid, ns30PriceSet);
					
					// -------------------------------Set Loss -----------------------------------
					
					if (nycaRegMap.containsKey(ptid)) {
						regPriceSet = (NyisoHourlyPriceSet) nycaRegMap.get(ptid);
					} else {
						regPriceSet = new NyisoHourlyPriceSet();
					}
					regPriceSet.setName(name);
					regPriceSet.setPtid(ptid);

					regPriceSet.setPrice(dt2,reg);

					nycaRegMap.put(ptid, ns30PriceSet);
				}
						
				} catch (Exception e) {
					System.out.println("ERRORRRRRRRR:"+e);
				}
		}
	}
	private DateTime nyTimestampToDateTime(String time) {
	
		DateTimeFormatter dtf;
		if(time.length() > 16) {
			dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
		} else {
			dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
		}
		 
	
		DateTime dt = dtf.parseDateTime(time);
		return(dt);
	}
	
	public HashMap <String, NyisoHourlyPriceSet> getSpin10minMap() {
		return spin10minMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getNonSpin10minMap() {
		return nonspin10minMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getNonSpin30minMap() {
		return nonspin30minMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getNycaRegMap() {
		return nycaRegMap;
	}
}
