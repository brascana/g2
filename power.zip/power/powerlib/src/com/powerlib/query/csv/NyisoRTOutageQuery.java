package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoRTOutage;
import com.powerlib.util.HttpFileDownload;


public class NyisoRTOutageQuery {
	
	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;
	
	private HashMap<String, NyisoRTOutage> outageMap;
	
	Set<DateTime> timeTable = new LinkedHashSet<DateTime>();
	
	public NyisoRTOutageQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		outageMap = new HashMap<String, NyisoRTOutage>();

	}
	public boolean query() {

		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		} else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					String ptid = csvReader.get(1);
					String equipName = csvReader.get(2);
					String dateStr = csvReader.get(3);


					DateTime dt = nyTimestampToDateTime(timestamp);
					DateTime dateOut = nyTimestampToDateTime(dateStr);

					NyisoRTOutage outage;
					
					if(!timeTable.contains(dt)){
						timeTable.add(dt);
					}

					if (outageMap.containsKey(ptid)) {
						outage = (NyisoRTOutage) outageMap.get(ptid);
					} else {
						outage = new NyisoRTOutage();
						outage.setPtid(ptid);
						outage.setDateOut(dateOut);
						outage.setEquipName(equipName);

					}
					outage.setOutageTime(dt);
					outageMap.put(ptid, outage);

				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}
	private DateTime nyTimestampToDateTime(String time) {

		DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");

		DateTime dt = dtf.parseDateTime(time);
		return (dt);
	}
	
	public HashMap <String,NyisoRTOutage> getOutageMap(){
		return outageMap;
	}
	
	public Set<DateTime> getTimeTable(){
		return timeTable;
	}

}
