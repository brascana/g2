package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoTransOut;
import com.powerlib.util.HttpFileDownload;

public class NyisoTransOutQuery {

	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;

	private HashMap<String, NyisoTransOut> outageMap;

	public NyisoTransOutQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		outageMap = new HashMap<String, NyisoTransOut>();

	}
	
	public boolean query() {
		if (downloader.downloadToString(urlPath)) {
			try {
				
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
				parse(csvReader);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}else {
			return false;
		}
		
		return true;
	}
	
	public void parse(CsvReader csvReader) {
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					String ptid = csvReader.get(1);
					String equipmentName = csvReader.get(2);

					String dateOut = csvReader.get(3);
					String dateIn = csvReader.get(4);

					NyisoTransOut outage;

					if (outageMap.containsKey(ptid)) {
						outage = (NyisoTransOut) outageMap.get(ptid);
					} else {
						outage = new NyisoTransOut();
					}

					outage.setPtid(ptid);
					outage.setEquipmentName(equipmentName);

					if (nyTimestampToDateTime(timestamp) != null)
						outage.setTimestamp(nyTimestampToDateTime(timestamp));

					if (nyTimestampToDateTimestamp(dateOut) != null)
						outage.setDateOut(nyTimestampToDateTimestamp(dateOut));

					if (nyTimestampToDateTimestamp(dateIn) != null)
						outage.setDateIn(nyTimestampToDateTimestamp(dateIn));

					outageMap.put(ptid, outage);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public boolean readCSVFile(){
		try {
			
			csvReader = new CsvReader(urlPath);
			parse(csvReader);
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return true;
	}
	
	private DateTime nyTimestampToDateTime(String dy) {

		try {
			String[] str = dy.split(" ");
			DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy");
			DateTime dt = dtf.parseDateTime(str[0]);
			return (dt);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	private DateTime nyTimestampToDateTimestamp(String dy) {

		try {

			DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
			DateTime dt = dtf.parseDateTime(dy);
			return (dt);

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public HashMap<String, NyisoTransOut> getOutageMap() {
		return outageMap;
	}
}