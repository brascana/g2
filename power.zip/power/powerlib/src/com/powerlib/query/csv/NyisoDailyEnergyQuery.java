package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoDailyEnergy;
import com.powerlib.util.HttpFileDownload;

public class NyisoDailyEnergyQuery {

	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;
	private String descriptions[];

	private HashMap<String, NyisoDailyEnergy> hourlyMap;

	public NyisoDailyEnergyQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		hourlyMap = new HashMap<String, NyisoDailyEnergy>();

	}

	public boolean query() {

		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		} else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				descriptions = csvReader.getHeaders();
				int hCount = descriptions.length;
				
				boolean insert = true;
				
				while (csvReader.readRecord()) {
					
					String timestamp = csvReader.get(0);
								
					
					for (int i = 1; i < hCount; i++) {
						
						
						String desc = descriptions[i];

						double value=0;
						
						try {
							value = Double.parseDouble(csvReader.get(i));
						}catch(Exception e) {
							insert = false;
						}
						
						try {
							NyisoDailyEnergy nyeng;
							DateTime dt = nyTimestampToDateTime(timestamp);
							
							if (hourlyMap.containsKey(desc)) {
								nyeng = (NyisoDailyEnergy) hourlyMap.get(desc);
								nyeng.setDescription(desc);
								nyeng.setHourlyValue(dt, value);
								//System.out.println(timestamp +desc);
							} else {
								nyeng = new NyisoDailyEnergy();
								nyeng.setDescription(desc);
								nyeng.setHourlyValue(dt, value);
								
							}
							if(insert){
								
								hourlyMap.put(desc, nyeng);
							}
							
						}catch(Exception e) {
							/*System.out.println("error "+timestamp);
							e.printStackTrace();*/

						}
						
					}
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}

	private DateTime nyTimestampToDateTime(String time) {

		DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");

		DateTime dt = dtf.parseDateTime(time);
		return (dt);
	}

	public HashMap<String, NyisoDailyEnergy> getHourlyMap() {
		return hourlyMap;
	}
}