package com.powerlib.query.csv;

import com.csvreader.CsvReader;
import com.powerlib.util.HttpFileDownload;

public class NyisoLoadFcstQuery {
	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;
	
	

}
