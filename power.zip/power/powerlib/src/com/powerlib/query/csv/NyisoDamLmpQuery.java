package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.util.HttpFileDownload;

public class NyisoDamLmpQuery {
	
	private CsvReader csvReader = null;
    private HttpFileDownload downloader;
    private String urlPath;
	
	private HashMap  <String,NyisoHourlyPriceSet>lbmpMap;
	private HashMap  <String,NyisoHourlyPriceSet>congMap;
	private HashMap  <String,NyisoHourlyPriceSet>lossMap;
		
	public NyisoDamLmpQuery(String path) {
		
		urlPath = path;
        downloader = new HttpFileDownload();
        
        lbmpMap = new HashMap<String, NyisoHourlyPriceSet>();
        congMap = new HashMap<String, NyisoHourlyPriceSet>();
        lossMap = new HashMap<String, NyisoHourlyPriceSet>();
        
	}
	public boolean readCSVFile(){
		try {
			
			csvReader = new CsvReader(urlPath);
			parse(csvReader);
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
		return true;
	}
	public void parse(CsvReader csvReader) {
		
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					String name = csvReader.get(1);
					String ptid = csvReader.get(2);

					double lbmp = Double.parseDouble(csvReader.get(3));
					double loss = Double.parseDouble(csvReader.get(4));
					double congestion = Double.parseDouble(csvReader.get(5));
					
					
					
					DateTime dt = nyTimestampToDateTime(timestamp);
										
					DateTime dt2 = dt;
					
					dt2.withZone(DateTimeZone.forID("America/New_York"));
													
					NyisoHourlyPriceSet lbmpPriceSet;
					NyisoHourlyPriceSet congPriceSet;
					NyisoHourlyPriceSet lossPriceSet;

					// -------------------------------Set LBMP ----------------------------------
					
					if (lbmpMap.containsKey(ptid)) {
						lbmpPriceSet = (NyisoHourlyPriceSet) lbmpMap.get(ptid);
					} else {
						lbmpPriceSet = new NyisoHourlyPriceSet();
						lbmpPriceSet.setName(name);
						lbmpPriceSet.setPtid(ptid);
					}

					if (lbmpPriceSet.containsHour(dt2)) {
						dt2 = dt2.plusHours(1);
					}
					lbmpPriceSet.setPrice(dt2, lbmp);
					lbmpMap.put(ptid, lbmpPriceSet);
					
					// -------------------------------Set Congestion ------------------------------
					
					if (congMap.containsKey(ptid)) {
						congPriceSet = (NyisoHourlyPriceSet) congMap.get(ptid);
					} else {
						congPriceSet = new NyisoHourlyPriceSet();
					}
					congPriceSet.setName(name);
					congPriceSet.setPtid(ptid);

					congPriceSet.setPrice(dt2, congestion);

					congMap.put(ptid, congPriceSet);
					
					// -------------------------------Set Loss -----------------------------------
					
					if (lossMap.containsKey(ptid)) {
						lossPriceSet = (NyisoHourlyPriceSet) lossMap.get(ptid);
					} else {
						lossPriceSet = new NyisoHourlyPriceSet();
					}
					lossPriceSet.setName(name);
					lossPriceSet.setPtid(ptid);

					lossPriceSet.setPrice(dt2, loss);

					lossMap.put(ptid, lossPriceSet);
				}
						
				} catch (Exception e) {
					System.out.println("ERRORRRRRRRR:"+e);
				}
		}
	}
	public boolean query() {
		if (downloader.downloadToString(urlPath)) {
			try {
				
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
				parse(csvReader);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}else {
			return false;
		}
		
		return true;
	}
	
	private DateTime nyTimestampToDateTime(String time) {
		
		DateTimeFormatter dtf;
		if(time.length() > 16) {
			dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
		} else {
			dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
		}
		 
		DateTime dt = dtf.parseDateTime(time);
		return(dt);
	}
	public HashMap <String, NyisoHourlyPriceSet> getLbmpMap() {
		return lbmpMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getCongMap() {
		return congMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getLossMap() {
		return lossMap;
	}
}
