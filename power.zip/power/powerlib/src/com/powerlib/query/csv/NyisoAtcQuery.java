package com.powerlib.query.csv;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.powergrid.NyisoAtcTtc;
import com.powerlib.util.HttpFileDownload;

public class NyisoAtcQuery {
	
	private CsvReader csvReader = null;
    private HttpFileDownload downloader;
    private String urlPath;
    
    private HashMap<String,NyisoAtcTtc> ttcMap;
    private HashMap<String,NyisoAtcTtc> atcMap;
    
    public NyisoAtcQuery(String path) {
    	
    	urlPath = path;
        downloader = new HttpFileDownload();
        
        ttcMap = new HashMap<String,NyisoAtcTtc>();
        atcMap = new HashMap<String,NyisoAtcTtc>();
        	
    }
    public boolean query() {
		
		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}else {
			return false;
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String name = csvReader.get(0);
					String timestamp = csvReader.get(1);
					
					double ttc = Double.parseDouble(csvReader.get(2));
					double atc = Double.parseDouble(csvReader.get(3));
					

					DateTime dt = nyTimestampToDateTime(timestamp);

					NyisoAtcTtc ttcPriceSet;
					NyisoAtcTtc atcPriceSet;


					// -------------------------------Set TTC ----------------------------------
					if (ttcMap.containsKey(name)) {
						ttcPriceSet = (NyisoAtcTtc) ttcMap.get(name);
					} else {
						ttcPriceSet = new NyisoAtcTtc();
						ttcPriceSet.setName(name);

					}

					ttcPriceSet.setHourlyValue(dt, ttc);

					ttcMap.put(name, ttcPriceSet);
					
					// -------------------------------Set ATC ---- ------------------------------
					
					if (atcMap.containsKey(name)) {
						atcPriceSet = (NyisoAtcTtc) atcMap.get(name);
					} else {
						atcPriceSet = new NyisoAtcTtc();
						atcPriceSet.setName(name);

					}

					atcPriceSet.setHourlyValue(dt, atc);

					atcMap.put(name, atcPriceSet);
					
						
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
			
		}
		return true;
	}
    
    private DateTime nyTimestampToDateTime(String time) {
		
		DateTimeFormatter dtf 
			= DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
		
		DateTime dt = dtf.parseDateTime(time);
		return(dt);
	}
    
    public HashMap<String, NyisoAtcTtc> getTtcMap() {
		return ttcMap;
	}
    
    public HashMap<String, NyisoAtcTtc> geAtcMap() {
		return atcMap;
	}


}
