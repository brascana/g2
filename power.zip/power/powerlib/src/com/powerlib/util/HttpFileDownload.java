package com.powerlib.util;

import java.io.*;
import java.net.*;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

public class HttpFileDownload {

	private URL url;
	private URLConnection con;
	private StringBuilder data = new StringBuilder();

	private BufferedReader br;

	public HttpFileDownload() {

	}
	
	public boolean downloadToFile(String urlString, File destination) {    
        try {
            URL website = new URL(urlString);
            ReadableByteChannel rbc;
            rbc = Channels.newChannel(website.openStream());
            FileOutputStream fos = new FileOutputStream(destination);
            fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
            fos.close();
            return true;
        } catch (IOException e) {
        	
            e.printStackTrace();
            return false;
        }
    }

	public boolean downloadToString(String u) {

		try {
			
			url = new URL(u);

			// open the url connection.
			con = url.openConnection();

			br = new BufferedReader(new InputStreamReader(con.getInputStream()));

			String line;
			while ((line = br.readLine()) != null) {
				data.append(line).append("\n");
			}

			// dis.close();
			br.close();

		} catch (Exception m) {
			System.out.println("cannot download: "+m);
			return false;
		} 

		return true;
	}

	public String getData() {
		return data.toString();
	}
}