package com.powerlib.powergrid;

import org.joda.time.DateTime;

public class NyisoTermTransOut {
	
	private String ptid;
	private String outageId;
	private String equipmentName;
	private String equipmentType;
	private DateTime dateOut;
	private DateTime dateIn;
	private String timeOut;
	private String timeIn;
	private String calledIn;
	private String status;
	private String statusDate;
	private String message;
	private String arr;
	
	public String getPtid() {
		return ptid;
	}
	public void setPtid(String ptid) {
		this.ptid = ptid;
	}
	public String getOutageId() {
		return outageId;
	}
	public void setOutageId(String outageId) {
		this.outageId = outageId;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public String getEquipmentType() {
		return equipmentType;
	}
	public void setEquipmentType(String equipmentType) {
		this.equipmentType = equipmentType;
	}
	public DateTime getDateOut() {
		return dateOut;
	}
	public String getTimeOut(){
		return timeOut;
	}
	public void setDateOut(DateTime dateOut) {
		this.dateOut = dateOut;
	}
	public DateTime getDateIn() {
		return dateIn;
	}
	public String getTimeIn(){
		return timeIn;
	}
	public void setDateIn(DateTime dateIn) {
		this.dateIn = dateIn;
	}
	public void setTimeIn(String ti){
		this.timeIn = ti;
	}
	public void setTimeOut(String to){
		this.timeOut = to;
	}
	public String getCalledIn() {
		return calledIn;
	}
	public void setCalledIn(String calledIn) {
		this.calledIn = calledIn;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusDate() {
		return statusDate;
	}
	public void setStatusDate(String statusDate) {
		this.statusDate = statusDate;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getArr() {
		return arr;
	}
	public void setArr(String arr) {
		this.arr = arr;
	}
		
}
