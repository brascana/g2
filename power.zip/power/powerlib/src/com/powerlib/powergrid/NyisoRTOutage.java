package com.powerlib.powergrid;

import java.util.LinkedHashSet;
import java.util.Set;

import org.joda.time.DateTime;

public class NyisoRTOutage {
		
	private String ptid;
	private String equipName;
	private DateTime dateOut;
	
	public Set<DateTime> outageTable = new LinkedHashSet<DateTime>();
	
	public NyisoRTOutage() {
	}
	
	public boolean hasInterval(DateTime dt){
		return outageTable.contains(dt);
	}
	public void setOutageTime(DateTime dt) {
		outageTable.add(dt);	
	}

	public String getPtid() {
		return ptid;
	}

	public void setPtid(String ptid) {
		this.ptid = ptid;
	}
	
	public String getEquipName() {
		return equipName;
	}

	public void setEquipName(String equipName) {
		this.equipName = equipName;
	}

	public DateTime getDateOut() {
		return dateOut;
	}

	public void setDateOut(DateTime dateOut) {
		this.dateOut = dateOut;
	}

}
