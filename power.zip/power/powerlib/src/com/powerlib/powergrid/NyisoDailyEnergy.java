package com.powerlib.powergrid;

import java.util.Hashtable;

import org.joda.time.DateTime;

public class NyisoDailyEnergy {
	
	protected String description;
	protected String category;
	
	// stores hourly price data
	protected Hashtable <DateTime,Double> hourlyTable;
	
	public void setDescription(String d) {
		description = d;
	}

	public String getDescription(){
		return description;
	}
	public void setCategory(String c) {
		category = c;
	}

	public String getCategory(){
		return category;
	}

	public NyisoDailyEnergy() {
		hourlyTable = new Hashtable <DateTime,Double>();
	}
	
	public void setHourlyValue(DateTime dt, double p) {
		hourlyTable.put(dt, p);
	}
	
	public boolean containsHour (DateTime dt) {
		return (hourlyTable.containsKey(dt));
	}
	
	public double getHourlyValue(DateTime dt) {
		return hourlyTable.get(dt);
	}
	
}