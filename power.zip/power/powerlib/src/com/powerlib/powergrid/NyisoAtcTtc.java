package com.powerlib.powergrid;

import java.util.Hashtable;

import org.joda.time.DateTime;

public class NyisoAtcTtc {
	
	protected String name;
	
	// stores hourly price data
	protected Hashtable <DateTime,Double> hourlyTable;
	

	public String getName(){
		return name;
	}
	
	public NyisoAtcTtc() {
		hourlyTable = new Hashtable <DateTime,Double>();
	}
	
	public void setHourlyValue(DateTime dt, double p) {
		hourlyTable.put(dt, p);
	}
	public void setName(String n){
		name = n;
	}
	
	public boolean containsHour (DateTime dt) {
		return (hourlyTable.containsKey(dt));
	}
	
	public double getHourlyValue(DateTime dt) {
		return hourlyTable.get(dt);
	}
	
}