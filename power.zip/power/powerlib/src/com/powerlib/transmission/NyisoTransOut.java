package com.powerlib.transmission;

import org.joda.time.DateTime;

public class NyisoTransOut {
	
	private DateTime timestamp;
	private String ptid;
	private String equipmentName;
	private DateTime dateOut;
	private DateTime datIn;
	
	public DateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(DateTime timestamp) {
		this.timestamp = timestamp;
	}
	public String getPtid() {
		return ptid;
	}
	public void setPtid(String ptid) {
		this.ptid = ptid;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public DateTime getDateOut() {
		return dateOut;
	}
	public void setDateOut(DateTime dateOut) {
		this.dateOut = dateOut;
	}
	public DateTime getDatIn() {
		return datIn;
	}
	public void setDatIn(DateTime datIn) {
		this.datIn = datIn;
	}

}
