package com.powerlib.transmission;

import org.joda.time.DateTime;

public class NyisoTtcf {
	
	private int recordId;
	private String facilityName;
	private DateTime dateOut;
	private DateTime dateIn;
	private String ati;
	private String calledIn;
	private String cancel1;
	private String modMes;
	private String cancel2;
	private String pathName;
	private String exportPathName;
	private long fwdTtcCap;
	private long fwdTtcImpact;
	private long fwdTtcInService;
	private long revTtcCap;
	private long revTtcImpact;
	private long revTtcInService;
	private String ptid;
	private String arr;
	
	
	public int getRecordId() {
		return recordId;
	}
	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}
	public String getFacilityName() {
		return facilityName;
	}
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	public DateTime getDateOut() {
		return dateOut;
	}
	public void setDateOut(DateTime dateOut) {
		this.dateOut = dateOut;
	}
	public DateTime getDateIn() {
		return dateIn;
	}
	public void setDateIn(DateTime dateIn) {
		this.dateIn = dateIn;
	}
	public String getAti() {
		return ati;
	}
	public void setAti(String ati) {
		this.ati = ati;
	}
	public String getCalledIn() {
		return calledIn;
	}
	public void setCalledIn(String calledIn) {
		this.calledIn = calledIn;
	}
	public String getCancel1() {
		return cancel1;
	}
	public void setCancel1(String cancel1) {
		this.cancel1 = cancel1;
	}
	public String getModMes() {
		return modMes;
	}
	public void setModMes(String modMes) {
		this.modMes = modMes;
	}
	public String getCancel2() {
		return cancel2;
	}
	public void setCancel2(String cancel2) {
		this.cancel2 = cancel2;
	}
	public String getPathName() {
		return pathName;
	}
	public void setPathName(String pathName) {
		this.pathName = pathName;
	}
	public String getExportPathName() {
		return exportPathName;
	}
	public void setExportPathName(String exportPathName) {
		this.exportPathName = exportPathName;
	}
	public long getFwdTtcCap() {
		return fwdTtcCap;
	}
	public void setFwdTtcCap(long fwdTtcCap) {
		this.fwdTtcCap = fwdTtcCap;
	}
	public long getFwdTtcImpact() {
		return fwdTtcImpact;
	}
	public void setFwdTtcImpact(long fwdTtcImpact) {
		this.fwdTtcImpact = fwdTtcImpact;
	}
	public long getFwdTtcInService() {
		return fwdTtcInService;
	}
	public void setFwdTtcInService(long fwdTtcInService) {
		this.fwdTtcInService = fwdTtcInService;
	}
	public long getRevTtcCap() {
		return revTtcCap;
	}
	public void setRevTtcCap(long revTtcCap) {
		this.revTtcCap = revTtcCap;
	}
	public long getRevTtcImpact() {
		return revTtcImpact;
	}
	public void setRevTtcImpact(long revTtcImpact) {
		this.revTtcImpact = revTtcImpact;
	}
	public long getRevTtcInService() {
		return revTtcInService;
	}
	public void setRevTtcInService(long revTtcInService) {
		this.revTtcInService = revTtcInService;
	}
	public String getPtid() {
		return ptid;
	}
	public void setPtid(String ptid) {
		this.ptid = ptid;
	}
	public String getArr() {
		return arr;
	}
	public void setArr(String arr) {
		this.arr = arr;
	}
	
	
}
