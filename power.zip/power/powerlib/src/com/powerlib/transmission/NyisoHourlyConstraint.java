package com.powerlib.transmission;

import java.util.Hashtable;

import org.joda.time.DateTime;

import com.powerlib.time.NyisoCalendar;

public class NyisoHourlyConstraint {

	private String ptid;
	private String limitingFacility;
	private String contingency;

	private Hashtable<DateTime, Double> costTable;

	private NyisoCalendar nyCal;

	public NyisoHourlyConstraint() {
		costTable = new Hashtable<DateTime, Double>();
		nyCal = new NyisoCalendar();
	}

	public void setCost(DateTime dt, double c) {
		costTable.put(dt, c);
	}

	public void setLimitingFacility(String f) {
		limitingFacility = f;
	}

	public void setPtid(String p) {
		ptid = p;
	}

	public void setContingency(String c) {
		contingency = c;
	}

	public String getPtid() {
		return ptid;
	}

	public String getLimitingFacility() {
		return limitingFacility;
	}

	public String getContingency() {
		return contingency;
	}

	public double get7x16Cost() {

		double hours = 0;
		double cost = 0;

		for (DateTime key : costTable.keySet()) {

			DateTime dt = (DateTime) key;
			if (nyCal.isPeakHour(dt)) {
				hours++;
				cost = cost + costTable.get(key);
			}

		}
		return (double) Math.round((cost / hours) * 100) / 100;
	}

	public double get7x8Cost() {

		double hours = 0;
		double cost = 0;

		for (DateTime key : costTable.keySet()) {

			DateTime dt = (DateTime) key;
			if (!nyCal.isPeakHour(dt)) {
				hours++;
				cost = cost + costTable.get(key);
			}

		}
		return (double) Math.round((cost / hours) * 100) / 100;
	}

	public double get7x24Cost() {

		double hours = 0;
		double cost = 0;

		for (DateTime key : costTable.keySet()) {
			hours++;
			cost = cost + costTable.get(key);

		}
		return (double) Math.round((cost / hours) * 100) / 100;
	}

}
