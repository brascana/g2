package com.powerlib.load;

import java.util.Hashtable;

import org.joda.time.DateTime;

public class NyisoHourlyLoad {
	
	private String zone;
	private String ptid;
	
	private Hashtable<DateTime, Double> loadTable;
	
	public NyisoHourlyLoad(){
		loadTable = new Hashtable <DateTime, Double>();
	}
	
	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getPtid() {
		return ptid;
	}

	public void setPtid(String ptid) {
		this.ptid = ptid;
	}
	
	public void setLoad(DateTime dt, double c) {
		loadTable.put(dt, c);
	}
	
	public boolean containsHour (DateTime dt) {
		return (loadTable.containsKey(dt));
	}
	
	public double getHourlyLoad(DateTime dt) {
		return loadTable.get(dt);
	}
	
}
