package com.powerlib.lmp;

public class NyisoFiveMinPriceSet {
	
}
