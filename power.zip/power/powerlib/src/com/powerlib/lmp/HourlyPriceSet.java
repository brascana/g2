package com.powerlib.lmp;

import java.util.Hashtable;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.joda.time.DateTime;

public class HourlyPriceSet {
	
	protected String name;
	protected String ptid;
	
	
	// stores hourly price data
	protected Hashtable <DateTime,Double> priceTable;
	
	public void setName(String n) {
		name = n;
	}
	public void setPtid(String p) {
		ptid = p;
	}
	public String getPtid(){
		return ptid;
	}
	public String getName(){
		return name;
	}
	public HourlyPriceSet() {
		priceTable = new Hashtable <DateTime,Double>();
	}
	
	public void setPrice(DateTime dt, double p) {
		priceTable.put(dt, p);
	}
	
	public boolean containsHour (DateTime dt) {
		return (priceTable.containsKey(dt));
	}
	
	public double getHourlyPrice(DateTime dt) {
		return priceTable.get(dt);
	}
	
	
}
