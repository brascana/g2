package com.powerlib.lmp;

import java.util.Iterator;
import java.util.NavigableSet;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.joda.time.DateTime;
import org.joda.time.format.*;

import com.powerlib.time.NyisoCalendar;

public class NyisoHourlyPriceSet extends HourlyPriceSet {
	
	private NyisoCalendar nyCal;
	public NyisoHourlyPriceSet() {
		nyCal = new NyisoCalendar();
	}
	
	public double get7x16Price() {
		
		double peakHours = 0;
		double peakPrice =0;
		
		
		for(DateTime key: priceTable.keySet()) {
			
			DateTime dt = (DateTime) key;
			if (nyCal.isPeakHour(dt)) {
				peakHours++;
				peakPrice = peakPrice + priceTable.get(key);
			}

		}
		return (double)Math.round((peakPrice / peakHours)*100)/100;
	}
	
	public double get7x8Price() {

		
		double offPeakHours = 0.00;
		double offPeakPrice = 0.00;

		for (DateTime key : priceTable.keySet()) {

			DateTime dt = (DateTime) key;
			if (!nyCal.isPeakHour(dt)) {
				offPeakHours++;
				
				offPeakPrice = (double)Math.round(
						(offPeakPrice + priceTable.get(key))*100)/100;

			}
		}
		
		return (double)Math.round(
				(offPeakPrice / offPeakHours)*100)/100;
		
	}
	public double get7x24Price() {

		double hours = 0.00;
		double price = 0.00;

		for (DateTime key : priceTable.keySet()) {

				hours++;
				price = (double)Math.round(
						(price + priceTable.get(key))*100)/100;
		}
		
		return (double)Math.round(
				(price / hours)*100)/100;
		
	}
	
	public String printHeader() {
		
		TreeMap<DateTime,Double> sortedPrices = new TreeMap<DateTime,Double>();
		
		String output="";
		sortedPrices.putAll(priceTable);
		
		NavigableSet<DateTime> navig = ((TreeMap<DateTime, Double>)sortedPrices ).descendingKeySet();
		
		DateTimeFormatter fmt = DateTimeFormat.forPattern("HH:mm");
		
		for (Iterator<DateTime> iter=navig.iterator();iter.hasNext();) {
		    DateTime key = (DateTime) iter.next();
		    
		    String priceVal = String.format("%s", fmt.print(key));
		    int pad = 7- priceVal.length();
		    
		    String fill="";
		    for(int i=1;i<=pad;i++){
		    	fill+=" ";
		    }
		    
		    
		    StringBuilder str = new StringBuilder(fill+priceVal);
		    
		    output += str.toString();
		    /*StringBuilder str = new StringBuilder(String.format("%s", fmt.print(key)));
		    str.setLength(7);
			output += str.toString();*/

	}
		
		return output;
	}
	public String print() {
		
		TreeMap<DateTime,Double> sortedPrices = new TreeMap<DateTime,Double>();
		
		String output="";
		sortedPrices.putAll(priceTable);
		
		NavigableSet<DateTime> navig = ((TreeMap<DateTime, Double>)sortedPrices ).descendingKeySet();
		
		
		for (Iterator<DateTime> iter=navig.iterator();iter.hasNext();) {
		    DateTime key = (DateTime) iter.next();
		    
		    
		    String priceVal = String.format("%.2f", sortedPrices.get(key));
		    int pad = 7- priceVal.length();
		    
		    String fill="";
		    for(int i=1;i<=pad;i++){
		    	fill+=" ";
		    }
		    		    
			output += fill+priceVal;

		}
		
		return output;
		
	}

}
