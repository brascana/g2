package com.powerlib.ancillary;

import java.util.Hashtable;

import org.joda.time.DateTime;

public class NyisoHourlyAncillary {
	
	protected String product;

	// stores hourly price data
	protected Hashtable <DateTime,Double> priceTable;
	
	public void setProduct(String p) {
		product = p;
	}

	public String getProduct(){
		return product;
	}

	public NyisoHourlyAncillary() {
		priceTable = new Hashtable <DateTime,Double>();
	}
	
	public void setPrice(DateTime dt, double p) {
		priceTable.put(dt, p);
	}
	
	public boolean containsHour (DateTime dt) {
		return (priceTable.containsKey(dt));
	}
	
	public double getHourlyPrice(DateTime dt) {
		return priceTable.get(dt);
	}
	
}