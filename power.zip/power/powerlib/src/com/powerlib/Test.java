package com.powerlib;

import java.util.HashMap;
import java.util.Set;

import org.joda.time.DateTime;

import com.powerlib.ancillary.NyisoHourlyAncillary;
import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.powergrid.NyisoDailyEnergy;
import com.powerlib.powergrid.NyisoHourlyConstraint;
import com.powerlib.powergrid.NyisoRTOutage;
import com.powerlib.powergrid.NyisoTermTransOut;
import com.powerlib.powergrid.NyisoTransOut;
import com.powerlib.powergrid.NyisoTtcf;
import com.powerlib.query.csv.NyisoDailyEnergyQuery;
import com.powerlib.query.csv.NyisoDamAncillaryQuery;
import com.powerlib.query.csv.NyisoDamConstraintQuery;
import com.powerlib.query.csv.NyisoDamLmpQuery;
import com.powerlib.query.csv.NyisoRTOutageQuery;
import com.powerlib.query.csv.NyisoTermTransOutQuery;
import com.powerlib.query.csv.NyisoTransOutQuery;
import com.powerlib.query.csv.NyisoTtcfQuery;

public class Test {

	public static void main(String[] args) {

		/*
		 * NyisoDamLmpQuery nydam = new NyisoDamLmpQuery(
		 * "http://mis.nyiso.com/public/csv/damlbmp/20150112damlbmp_zone.csv");
		 * 
		 * NyisoDamConstraintQuery nydam2 = new NyisoDamConstraintQuery(
		 * "http://mis.nyiso.com/public/csv/DAMLimitingConstraints/20141207DAMLimitingConstraints.csv"
		 * );
		 */
		NyisoTermTransOutQuery nydam3 = new NyisoTermTransOutQuery(
				"http://mis.nyiso.com/public/csv/os/outage-schedule.csv");

		NyisoRTOutageQuery rtout = new NyisoRTOutageQuery(
				"http://mis.nyiso.com/public/csv/realtimelineoutages/20151202RTLineOutages.csv");
		
		
		/*
		 * NyisoTransOutQuery nydam4 = new NyisoTransOutQuery(
		 * "http://mis.nyiso.com/public/csv/outSched/20141207outSched.csv");
		 * 
		 * NyisoTtcfQuery nydam5 = new
		 * NyisoTtcfQuery("http://mis.nyiso.com/public/pdf/ttcf/ttcf.csv");
		 * 
		 * 
		 * NyisoDamAncillaryQuery nydam6 = new NyisoDamAncillaryQuery(
		 * "http://mis.nyiso.com/public/csv/damasp/20150114damasp.csv");
		 */

		/*
		 * NyisoDailyEnergyQuery nydam7 = new NyisoDailyEnergyQuery(
		 * "http://mis.nyiso.com/public/csv/damenergy/20150115DAM_energy_rep.csv"
		 * );
		 * 
		 * if(nydam7.query()) {
		 * 
		 * HashMap<String, NyisoDailyEnergy> hm = nydam7.getHourlyMap();
		 * 
		 * for(String key: hm.keySet()) {
		 * 
		 * NyisoDailyEnergy nyps2 = hm.get(key); System.out.println(key); }
		 * 
		 * }
		 */

		/*
		 * if(nydam.query()) {
		 * 
		 * HashMap<String, NyisoHourlyPriceSet> hm = nydam.getLbmpMap();
		 * 
		 * for(String key: hm.keySet()) {
		 * 
		 * NyisoHourlyPriceSet nyps2 = hm.get(key); System.out.println(key +" "
		 * + nyps2.getName() +" " + nyps2.get7x8Price()); }
		 * 
		 * }
		 * 
		 * if(nydam6.query()) {
		 * 
		 * HashMap<String, NyisoHourlyAncillary> hm = nydam6.getE10SMap();
		 * 
		 * for(String key: hm.keySet()) {
		 * 
		 * NyisoHourlyAncillary nyps2 = hm.get(key); System.out.println(key +" "
		 * + nyps2.getProduct()); }
		 * 
		 * }
		 * 
		 * if (nydam2.query()) { HashMap<String, NyisoHourlyConstraint> hm2 =
		 * nydam2.getConstraintMap();
		 * 
		 * for (String key : hm2.keySet()) {
		 * 
		 * NyisoHourlyConstraint nyhc = hm2.get(key); System.out.println(key +
		 * " " + nyhc.getLimitingFacility() + " " + nyhc.get7x24Cost()); } }
		 */
		/*
		 * if (nydam3.query()) { HashMap<String, NyisoTermTransOut> hm3 =
		 * nydam3.getOutageMap();
		 * 
		 * for (String key : hm3.keySet()) {
		 * 
		 * NyisoTermTransOut nyto = hm3.get(key); System.out.println(key + " " +
		 * nyto.getOutageId() + " " + nyto.getDateOut().getHourOfDay()); } }
		 */

		if (rtout.query()) {
			HashMap<String, NyisoRTOutage> outMap = rtout.getOutageMap();
			Set<DateTime> timeTable = rtout.getTimeTable();

			System.out.printf("%30s ", "");
			
			for (DateTime dt : timeTable) {
				String time = String.format("%s:%s", dt.getHourOfDay(),
						dt.getMinuteOfHour(), dt.getSecondOfMinute());
				System.out.printf("%5s ", time);

			}

			System.out.println(" ");

			
			for (String key : outMap.keySet()) {
				NyisoRTOutage rt = outMap.get(key);
				System.out.printf("%30s", rt.getEquipName());
				
				for (DateTime dt : timeTable) {
					
					if (rt.hasInterval(dt)) {
						String x = "x";
						System.out.printf("%5s ", x);

					}else{
						String x = " ";
						System.out.printf("%5s ", x);
					}
				}
				System.out.print("\n");
				
			}
			
			/*
			String equip="";
			int row=0;
			for (DateTime dt : timeTable) {
				
				for (String key : outMap.keySet()) {
					int col = 0;
					NyisoRTOutage rt = outMap.get(key);
					
					
					if(col==0 && row ==0) {
						System.out.printf("%8s", rt.getEquipName());
					}

					if (rt.hasInterval(dt)) {
						String x = "x";
						System.out.printf("%8s", x);

					}
					col++;
				}
				row++;
				System.out.print("\n");

			}*/

		}
		/*
		 * if (nydam4.query()) { HashMap<String, NyisoTransOut> hm4 =
		 * nydam4.getOutageMap();
		 * 
		 * for (String key : hm4.keySet()) {
		 * 
		 * NyisoTransOut nyto = hm4.get(key); System.out.println(key + " " +
		 * nyto.getPtid() + " " + nyto.getEquipmentName()); } }
		 * 
		 * if (nydam5.query()) { HashMap<Integer, NyisoTtcf> hm5 =
		 * nydam5.getTtcfMap();
		 * 
		 * for (Integer key : hm5.keySet()) {
		 * 
		 * NyisoTtcf nyttcf = hm5.get(key); System.out.println(key + " " +
		 * nyttcf.getPtid() + " "+ nyttcf.getFwdTtcImpact()); } }
		 */

	}
}
