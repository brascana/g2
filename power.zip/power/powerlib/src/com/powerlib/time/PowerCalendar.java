	package com.powerlib.time;

import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTimeConstants;
import org.joda.time.LocalDate;

public class PowerCalendar {
	
	protected static final List<LocalDate> NERC_HOLIDAYS = Arrays.asList(new LocalDate[] {
		//2003
		new LocalDate(2003, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2003, DateTimeConstants.MAY, 26),      // Memorial Day
		new LocalDate(2003, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2003, DateTimeConstants.SEPTEMBER, 1), // Labor Day
		new LocalDate(2003, DateTimeConstants.NOVEMBER, 27), // Thanksgiving Day
		new LocalDate(2003, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2004
		new LocalDate(2004, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2004, DateTimeConstants.MAY, 31),      // Memorial Day
		new LocalDate(2004, DateTimeConstants.JULY, 5),      // Independence Day
		new LocalDate(2004, DateTimeConstants.SEPTEMBER, 6), // Labor Day
		new LocalDate(2004, DateTimeConstants.NOVEMBER, 25), // Thanksgiving Day
		new LocalDate(2004, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2005
		new LocalDate(2005, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2005, DateTimeConstants.MAY, 30),      // Memorial Day
		new LocalDate(2005, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2005, DateTimeConstants.SEPTEMBER, 5), // Labor Day
		new LocalDate(2005, DateTimeConstants.NOVEMBER, 24), // Thanksgiving Day
		new LocalDate(2005, DateTimeConstants.DECEMBER, 26), // Christmas Day
		//2006
		new LocalDate(2006, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2006, DateTimeConstants.MAY, 29),      // Memorial Day
		new LocalDate(2006, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2006, DateTimeConstants.SEPTEMBER, 4), // Labor Day
		new LocalDate(2006, DateTimeConstants.NOVEMBER, 23), // Thanksgiving Day
		new LocalDate(2006, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2007
		new LocalDate(2007, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2007, DateTimeConstants.MAY, 28),      // Memorial Day
		new LocalDate(2007, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2007, DateTimeConstants.SEPTEMBER, 3), // Labor Day
		new LocalDate(2007, DateTimeConstants.NOVEMBER, 22), // Thanksgiving Day
		new LocalDate(2007, DateTimeConstants.DECEMBER, 25), // Christmas Day	
		//2008
		new LocalDate(2008, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2008, DateTimeConstants.MAY, 26),      // Memorial Day
		new LocalDate(2008, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2008, DateTimeConstants.SEPTEMBER, 1), // Labor Day
		new LocalDate(2008, DateTimeConstants.NOVEMBER, 27), // Thanksgiving Day
		new LocalDate(2008, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2009
		new LocalDate(2009, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2009, DateTimeConstants.MAY, 25),      // Memorial Day
		new LocalDate(2009, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2009, DateTimeConstants.SEPTEMBER, 7), // Labor Day
		new LocalDate(2009, DateTimeConstants.NOVEMBER, 26), // Thanksgiving Day
		new LocalDate(2009, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2010
		new LocalDate(2010, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2010, DateTimeConstants.MAY, 31),      // Memorial Day
		new LocalDate(2010, DateTimeConstants.JULY, 5),      // Independence Day
		new LocalDate(2010, DateTimeConstants.SEPTEMBER, 6), // Labor Day
		new LocalDate(2010, DateTimeConstants.NOVEMBER, 25), // Thanksgiving Day
		new LocalDate(2010, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2011
		new LocalDate(2011, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2011, DateTimeConstants.MAY, 30),      // Memorial Day
		new LocalDate(2011, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2011, DateTimeConstants.SEPTEMBER, 5), // Labor Day
		new LocalDate(2011, DateTimeConstants.NOVEMBER, 24), // Thanksgiving Day
		new LocalDate(2011, DateTimeConstants.DECEMBER, 26), // Christmas Day
		//2012
		new LocalDate(2012, DateTimeConstants.JANUARY, 2),   // New Years
		new LocalDate(2012, DateTimeConstants.MAY, 28),      // Memorial Day
		new LocalDate(2012, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2012, DateTimeConstants.SEPTEMBER, 3), // Labor Day
		new LocalDate(2012, DateTimeConstants.NOVEMBER, 22), // Thanksgiving Day
		new LocalDate(2012, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2013
		new LocalDate(2013, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2013, DateTimeConstants.MAY, 27),      // Memorial Day
		new LocalDate(2013, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2013, DateTimeConstants.SEPTEMBER, 2), // Labor Day
		new LocalDate(2013, DateTimeConstants.NOVEMBER, 28), // Thanksgiving Day
		new LocalDate(2013, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2014
		new LocalDate(2014, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2014, DateTimeConstants.MAY, 26),      // Memorial Day
		new LocalDate(2014, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2014, DateTimeConstants.SEPTEMBER, 1), // Labor Day
		new LocalDate(2014, DateTimeConstants.NOVEMBER, 27), // Thanksgiving Day
		new LocalDate(2014, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2015
		new LocalDate(2015, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2015, DateTimeConstants.MAY, 25),      // Memorial Day
		new LocalDate(2015, DateTimeConstants.JULY, 5),      // Independence Day
		new LocalDate(2015, DateTimeConstants.SEPTEMBER, 7), // Labor Day
		new LocalDate(2015, DateTimeConstants.NOVEMBER, 26), // Thanksgiving Day
		new LocalDate(2015, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2016
		new LocalDate(2016, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2016, DateTimeConstants.MAY, 30),      // Memorial Day
		new LocalDate(2016, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2016, DateTimeConstants.SEPTEMBER, 5), // Labor Day
		new LocalDate(2016, DateTimeConstants.NOVEMBER, 24), // Thanksgiving Day
		new LocalDate(2016, DateTimeConstants.DECEMBER, 26), // Christmas Day
		//2017
		new LocalDate(2017, DateTimeConstants.JANUARY, 2),   // New Years
		new LocalDate(2017, DateTimeConstants.MAY, 29),      // Memorial Day
		new LocalDate(2017, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2017, DateTimeConstants.SEPTEMBER, 4), // Labor Day
		new LocalDate(2017, DateTimeConstants.NOVEMBER, 23), // Thanksgiving Day
		new LocalDate(2017, DateTimeConstants.DECEMBER, 25), // Christmas Day
		//2018
		new LocalDate(2018, DateTimeConstants.JANUARY, 1),   // New Years
		new LocalDate(2018, DateTimeConstants.MAY, 28),      // Memorial Day
		new LocalDate(2018, DateTimeConstants.JULY, 4),      // Independence Day
		new LocalDate(2018, DateTimeConstants.SEPTEMBER, 3), // Labor Day
		new LocalDate(2018, DateTimeConstants.NOVEMBER, 22), // Thanksgiving Day
		new LocalDate(2018, DateTimeConstants.DECEMBER, 25), // Christmas Day
		

	});

}
