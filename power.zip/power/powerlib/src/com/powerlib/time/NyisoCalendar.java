package com.powerlib.time;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

public class NyisoCalendar extends PowerCalendar {
	
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean isPeakHour(DateTime dt) {
		return (dt.getHourOfDay() >6 && dt.getHourOfDay() < 23);
	}
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean is7x16(DateTime dt) {
		return (isPeakHour(dt));
	}
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean is7x8(DateTime dt) {
		return (!isPeakHour(dt));
	}
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean is2x16(DateTime dt) {
		return ((isWeekend(dt) || isNercHoliday(dt)) && isPeakHour(dt));
	}
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean is5x16(DateTime dt) {
		return (isPeakDay(dt) && isPeakHour(dt));
	}
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean is5x8(DateTime dt) {
		return (isPeakDay(dt) && !isPeakHour(dt));
	}
	/**
	 * 
	 * @param dt
	 * @return
	 */
	public boolean is2x8(DateTime dt) {
		return (!isWeekend(dt) && !isNercHoliday(dt) && !isPeakHour(dt));
	}
	
	public boolean isPeakDay(DateTime dt) {
		return (!isWeekend(dt) && !isNercHoliday(dt));
	}
	
	public boolean isWeekend(DateTime dt) {
		return (dt.getDayOfWeek() == 6 || dt.getDayOfWeek() == 7);
	}


	public boolean isNercHoliday(LocalDateTime checkedDate) {
		for (final LocalDate date : NERC_HOLIDAYS) {
			if (date.getMonthOfYear() == checkedDate.getMonthOfYear()
					&& date.getDayOfMonth() == checkedDate.getDayOfMonth()
					&& date.getYear() == checkedDate.getYear()) {
				return true;
			}
		}

		return false;
	}

	public boolean isNercHoliday(DateTime dt) {
		LocalDate checkedDate = new LocalDate(dt.toLocalDate());
		for (final LocalDate date : NERC_HOLIDAYS) {
			if (date.getMonthOfYear() == checkedDate.getMonthOfYear()
					&& date.getDayOfMonth() == checkedDate.getDayOfMonth()
					&& date.getYear() == checkedDate.getYear()) {
				return true;
			}
		}
		return false;
	}
	

	
	public boolean hasExtraHour(LocalDate ld) {
		return false;
	}
}
