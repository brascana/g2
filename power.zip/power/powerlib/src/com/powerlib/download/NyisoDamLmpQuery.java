package com.powerlib.download;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.csvreader.CsvReader;
import com.powerlib.lmp.NyisoHourlyPriceSet;
import com.powerlib.util.HttpFileDownload;

public class NyisoDamLmpQuery {
	
	private CsvReader csvReader = null;
    private HttpFileDownload downloader;
    private String urlPath;
	
	private HashMap  <String,NyisoHourlyPriceSet>lbmpMap;
	private HashMap  <String,NyisoHourlyPriceSet>congMap;
	private HashMap  <String,NyisoHourlyPriceSet>lossMap;
		
	public NyisoDamLmpQuery(String path) {
		
		urlPath = path;
        downloader = new HttpFileDownload();
        
        lbmpMap = new HashMap<String, NyisoHourlyPriceSet>();
        congMap = new HashMap<String, NyisoHourlyPriceSet>();
        lossMap = new HashMap<String, NyisoHourlyPriceSet>();  
	}
	
	public boolean query() {
		
		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					String name = csvReader.get(1);
					String ptid = csvReader.get(2);

					double lbmp = Double.parseDouble(csvReader.get(3));
					double loss = Double.parseDouble(csvReader.get(4));
					double congestion = Double.parseDouble(csvReader.get(5));

					DateTime dt = nyTimestampToDateTime(timestamp);

					NyisoHourlyPriceSet lbmpPriceSet;
					NyisoHourlyPriceSet congPriceSet;
					NyisoHourlyPriceSet lossPriceSet;

					// -------------------------------Set LBMP ----------------------------------
					if (lbmpMap.containsKey(ptid)) {
						lbmpPriceSet = (NyisoHourlyPriceSet) lbmpMap.get(ptid);
					} else {
						lbmpPriceSet = new NyisoHourlyPriceSet();
						lbmpPriceSet.setName(name);
						lbmpPriceSet.setPtid(ptid);
					}

					lbmpPriceSet.setPrice(dt, lbmp);

					lbmpMap.put(ptid, lbmpPriceSet);
					
					// -------------------------------Set Congestion ------------------------------
					
					if (congMap.containsKey(ptid)) {
						congPriceSet = (NyisoHourlyPriceSet) congMap.get(ptid);
					} else {
						congPriceSet = new NyisoHourlyPriceSet();
					}
					congPriceSet.setName(name);
					congPriceSet.setPtid(ptid);

					congPriceSet.setPrice(dt, congestion);

					congMap.put(ptid, congPriceSet);
					
					// -------------------------------Set Loss -----------------------------------
					
					if (lossMap.containsKey(ptid)) {
						lossPriceSet = (NyisoHourlyPriceSet) lossMap.get(ptid);
					} else {
						lossPriceSet = new NyisoHourlyPriceSet();
					}
					lossPriceSet.setName(name);
					lossPriceSet.setPtid(ptid);

					lossPriceSet.setPrice(dt, loss);

					lossMap.put(ptid, lossPriceSet);
						
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
			
		}
		return true;
	}
	
	private DateTime nyTimestampToDateTime(String time) {
		
		DateTimeFormatter dtf 
			= DateTimeFormat.forPattern("MM/dd/yyyy HH:mm");
		
		DateTime dt = dtf.parseDateTime(time);
		return(dt);
	}
	public HashMap <String, NyisoHourlyPriceSet> getLbmpMap() {
		return lbmpMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getCongMap() {
		return congMap;
	}
	public HashMap <String, NyisoHourlyPriceSet> getLossMap() {
		return lossMap;
	}
}
