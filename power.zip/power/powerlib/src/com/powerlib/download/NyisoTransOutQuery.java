package com.powerlib.download;

import java.io.StringReader;
import java.util.HashMap;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import com.csvreader.CsvReader;
import com.powerlib.transmission.NyisoTransOut;
import com.powerlib.util.HttpFileDownload;

public class NyisoTransOutQuery {

	private CsvReader csvReader = null;
	private HttpFileDownload downloader;
	private String urlPath;

	private HashMap<String, NyisoTransOut> outageMap;

	public NyisoTransOutQuery(String path) {

		urlPath = path;
		downloader = new HttpFileDownload();
		outageMap = new HashMap<String, NyisoTransOut>();

	}

	public boolean query() {

		if (downloader.downloadToString(urlPath)) {
			try {
				StringReader sr = new StringReader(downloader.getData());
				csvReader = new CsvReader(sr);
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		if (csvReader != null) {
			try {
				csvReader.readHeaders();

				while (csvReader.readRecord()) {

					String timestamp = csvReader.get(0);
					String ptid = csvReader.get(1);
					String equipmentName = csvReader.get(2);

					String dateOut = csvReader.get(3);
					String dateIn = csvReader.get(4);

					NyisoTransOut outage;

					if (outageMap.containsKey(ptid)) {
						outage = (NyisoTransOut) outageMap.get(ptid);
					} else {
						outage = new NyisoTransOut();
					}

					outage.setPtid(ptid);
					outage.setEquipmentName(equipmentName);

					if (nyTimestampToDateTime(timestamp) != null)
						outage.setTimestamp(nyTimestampToDateTime(timestamp));

					if (nyTimestampToDateTime(dateOut) != null)
						outage.setDateOut(nyTimestampToDateTime(dateOut));

					if (nyTimestampToDateTime(dateIn) != null)
						outage.setDateOut(nyTimestampToDateTime(dateIn));

					outageMap.put(ptid, outage);
				}
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}

	private DateTime nyTimestampToDateTime(String dy) {

		try {
			DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy");
			DateTime dt = dtf.parseDateTime(dy);
			return (dt);

		} catch (Exception e) {

			return null;
		}

	}

	public HashMap<String, NyisoTransOut> getOutageMap() {
		return outageMap;
	}
}